package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.model.MovementType
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.repository.CartItem
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var db: AppDatabase
  private lateinit var repository: ShopRepository

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repository = ShopRepository(db)
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ShopMaster POS & Store", appName)
  }

  @Test
  fun `test offline sale atomically reduces inventory and records audit log`() = runBlocking {
    // Insert initial product
    val productId = db.productDao().insert(
      Product(
        name = "Organic Whole Milk 1L",
        sellingPrice = 65.0,
        costPrice = 45.0,
        currentStock = 20.0,
        minStockLevel = 5.0,
        unit = "l"
      )
    )

    val product = db.productDao().getProductById(productId)
    assertNotNull(product)

    // Execute offline POS sale for 3 units
    val cartItems = listOf(CartItem(product = product!!, quantity = 3.0))
    val result = repository.processOfflineSale(
      cartItems = cartItems,
      customer = null,
      cashierName = "Cashier Test",
      subtotal = 195.0,
      discount = 0.0,
      tax = 0.0,
      totalAmount = 195.0,
      paymentMethod = PaymentMethod.CASH
    )

    assertTrue(result.isSuccess)

    // Check inventory stock is now 17.0
    val updatedProduct = db.productDao().getProductById(productId)
    assertEquals(17.0, updatedProduct?.currentStock ?: 0.0, 0.001)

    // Check audit logs
    val logs = db.auditDao().getAllLogs().first()
    assertTrue(logs.any { it.action == "OFFLINE_POS_SALE" })
  }
}

