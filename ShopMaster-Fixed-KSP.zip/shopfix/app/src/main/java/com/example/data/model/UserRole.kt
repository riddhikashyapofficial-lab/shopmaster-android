package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole(val displayName: String, val description: String) {
    OWNER("Owner / Admin", "Full administrative control over all shop operations"),
    MANAGER("Manager", "Orders, inventory, sales, cash & reports"),
    CASHIER("Cashier", "Offline POS sales, billing & customer lookup"),
    STOCK_STAFF("Stock Staff", "Inventory receiving, damage recording & stock counts"),
    DELIVERY_STAFF("Delivery Staff", "Order delivery routing, status & COD collection"),
    CUSTOMER("Customer", "Online shopping, cart, order tracking & profile")
}

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val role: UserRole,
    val pinCode: String = "1234",
    val isActive: Boolean = true,
    val canManageInventory: Boolean = true,
    val canManageCash: Boolean = true,
    val canViewReports: Boolean = true,
    val canDiscount: Boolean = true,
    val maxDiscountPercent: Double = 20.0,
    val createdAt: Long = System.currentTimeMillis()
)
