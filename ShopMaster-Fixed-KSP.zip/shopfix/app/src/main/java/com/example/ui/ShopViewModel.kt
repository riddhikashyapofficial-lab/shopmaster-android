package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.CashRegisterSession
import com.example.data.model.CashTransaction
import com.example.data.model.Category
import com.example.data.model.Customer
import com.example.data.model.CustomerAddress
import com.example.data.model.DeliveryType
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.InventoryMovement
import com.example.data.model.MovementType
import com.example.data.model.OfflineSale
import com.example.data.model.OfflineSaleItem
import com.example.data.model.Order
import com.example.data.model.OrderItem
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseOrderItem
import com.example.data.model.ShopSettings
import com.example.data.model.Supplier
import com.example.data.model.UserRole
import com.example.data.repository.CartItem
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

enum class AnalyticsTimeRange(val label: String) {
    TODAY("Today"),
    YESTERDAY("Yesterday"),
    THIS_WEEK("This Week"),
    THIS_MONTH("This Month"),
    ALL_TIME("All Time")
}

data class PosCartEntry(
    val product: Product,
    val quantity: Double,
    val unitDiscount: Double = 0.0
)

data class SalesAnalyticsSummary(
    val totalRevenue: Double = 0.0,
    val totalCostOfGoods: Double = 0.0,
    val grossProfit: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val netProfit: Double = 0.0,
    val totalTransactionsCount: Int = 0,
    val onlineOrdersCount: Int = 0,
    val offlineSalesCount: Int = 0,
    val cashSalesAmount: Double = 0.0,
    val upiSalesAmount: Double = 0.0,
    val cardSalesAmount: Double = 0.0,
    val averageOrderValue: Double = 0.0,
    val bestSellingProducts: List<Pair<String, Double>> = emptyList(),
    val categoryBreakdown: Map<String, Double> = emptyMap()
)

class ShopViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    val repository = ShopRepository(db)

    // Current Active Role & User
    private val _currentRole = MutableStateFlow(UserRole.OWNER)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    private val _currentOperatorName = MutableStateFlow("Vikram Sharma (Owner)")
    val currentOperatorName: StateFlow<String> = _currentOperatorName.asStateFlow()

    // Selected Customer for Customer Shopping view
    private val _activeCustomer = MutableStateFlow<Customer?>(null)
    val activeCustomer: StateFlow<Customer?> = _activeCustomer.asStateFlow()

    // Online Shopping Cart (Product ID -> CartItem)
    private val _customerCart = MutableStateFlow<Map<Long, CartItem>>(emptyMap())
    val customerCart: StateFlow<Map<Long, CartItem>> = _customerCart.asStateFlow()

    // POS Billing Cart
    private val _posCart = MutableStateFlow<List<PosCartEntry>>(emptyList())
    val posCart: StateFlow<List<PosCartEntry>> = _posCart.asStateFlow()

    private val _posSelectedCustomer = MutableStateFlow<Customer?>(null)
    val posSelectedCustomer: StateFlow<Customer?> = _posSelectedCustomer.asStateFlow()

    private val _posOverallDiscount = MutableStateFlow(0.0)
    val posOverallDiscount: StateFlow<Double> = _posOverallDiscount.asStateFlow()

    // Search and Filters
    private val _productSearchQuery = MutableStateFlow("")
    val productSearchQuery: StateFlow<String> = _productSearchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<Long?>(null)
    val selectedCategoryId: StateFlow<Long?> = _selectedCategoryId.asStateFlow()

    private val _orderStatusFilter = MutableStateFlow<OrderStatus?>(null)
    val orderStatusFilter: StateFlow<OrderStatus?> = _orderStatusFilter.asStateFlow()

    private val _analyticsTimeRange = MutableStateFlow(AnalyticsTimeRange.TODAY)
    val analyticsTimeRange: StateFlow<AnalyticsTimeRange> = _analyticsTimeRange.asStateFlow()

    // Data streams from repository
    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orderItems: StateFlow<List<OrderItem>> = repository.allOrderItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlineSales: StateFlow<List<OfflineSale>> = repository.allOfflineSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlineSaleItems: StateFlow<List<OfflineSaleItem>> = repository.allOfflineSaleItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentSession: StateFlow<CashRegisterSession?> = repository.currentOpenSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allSessions: StateFlow<List<CashRegisterSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cashTransactions: StateFlow<List<CashTransaction>> = repository.allCashTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val suppliers: StateFlow<List<Supplier>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchaseOrders: StateFlow<List<PurchaseOrder>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movements: StateFlow<List<InventoryMovement>> = repository.allInventoryMovements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadCount: StateFlow<Int> = repository.unreadNotificationsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val shopSettings: StateFlow<ShopSettings?> = repository.shopSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val employees: StateFlow<List<Employee>> = repository.allEmployees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products for Catalog & POS
    val filteredProducts = combine(products, _productSearchQuery, _selectedCategoryId) { prods, query, catId ->
        prods.filter { p ->
            val matchQuery = query.isBlank() ||
                    p.name.contains(query, ignoreCase = true) ||
                    p.sku.contains(query, ignoreCase = true) ||
                    p.barcode.contains(query, ignoreCase = true)
            val matchCat = catId == null || p.categoryId == catId
            matchQuery && matchCat
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined Unified Sales Analytics Calculation
    val analyticsSummary = combine(
        combine(orders, orderItems, offlineSales) { ord, oi, os -> Triple(ord, oi, os) },
        combine(offlineSaleItems, expenses, _analyticsTimeRange) { osi, exp, rng -> Triple(osi, exp, rng) }
    ) { (ord, oi, os), (osi, exp, rng) ->
        calculateAnalytics(ord, oi, os, osi, exp, rng)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SalesAnalyticsSummary())


    init {
        // Automatically select first customer as active customer if available
        viewModelScope.launch {
            repository.allCustomers.collect { list ->
                if (_activeCustomer.value == null && list.isNotEmpty()) {
                    _activeCustomer.value = list.first()
                }
            }
        }
    }

    // Role Switching
    fun setCurrentRole(newRole: UserRole) {
        switchRole(newRole)
    }

    fun switchRole(newRole: UserRole, operatorName: String? = null) {

        _currentRole.value = newRole
        _currentOperatorName.value = operatorName ?: when (newRole) {
            UserRole.OWNER -> "Vikram Sharma (Owner)"
            UserRole.MANAGER -> "Ananya Rao (Manager)"
            UserRole.CASHIER -> "Rohan Verma (Cashier)"
            UserRole.STOCK_STAFF -> "Deepak Yadav (Stock Staff)"
            UserRole.DELIVERY_STAFF -> "Sunil Kumar (Delivery Staff)"
            UserRole.CUSTOMER -> _activeCustomer.value?.name ?: "Customer"
        }
    }

    fun setActiveCustomer(customer: Customer) {
        _activeCustomer.value = customer
        if (_currentRole.value == UserRole.CUSTOMER) {
            _currentOperatorName.value = customer.name
        }
    }

    // Customer Shopping Cart Controls
    fun addToCustomerCart(product: Product, quantity: Double = 1.0) {
        val current = _customerCart.value.toMutableMap()
        val existing = current[product.id]
        val newQty = (existing?.quantity ?: 0.0) + quantity
        if (newQty <= 0.0) {
            current.remove(product.id)
        } else {
            current[product.id] = CartItem(product, newQty)
        }
        _customerCart.value = current
    }

    fun updateCustomerCartQuantity(productId: Long, newQuantity: Double) {
        val current = _customerCart.value.toMutableMap()
        if (newQuantity <= 0.0) {
            current.remove(productId)
        } else {
            val item = current[productId]
            if (item != null) {
                current[productId] = item.copy(quantity = newQuantity)
            }
        }
        _customerCart.value = current
    }

    fun clearCustomerCart() {
        _customerCart.value = emptyMap()
    }

    fun checkoutCustomerOrder(
        deliveryType: DeliveryType,
        deliveryAddress: String,
        deliveryInstructions: String,
        paymentMethod: PaymentMethod,
        discount: Double = 0.0,
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        val cust = _activeCustomer.value
        if (cust == null) {
            onError("Please select a customer profile")
            return
        }
        val items = _customerCart.value.values.toList()
        if (items.isEmpty()) {
            onError("Cart is empty")
            return
        }

        viewModelScope.launch {
            val settings = repository.shopSettingsDao.getSettingsDirect()
            val deliveryFee = if (deliveryType == DeliveryType.HOME_DELIVERY) (settings?.deliveryCharge ?: 25.0) else 0.0
            val res = repository.placeCustomerOrder(
                cartItems = items,
                customer = cust,
                deliveryType = deliveryType,
                deliveryAddress = deliveryAddress,
                deliveryInstructions = deliveryInstructions,
                paymentMethod = paymentMethod,
                deliveryCharge = deliveryFee,
                discount = discount
            )
            res.onSuccess { orderId ->
                clearCustomerCart()
                onSuccess(orderId)
            }.onFailure { err ->
                onError(err.message ?: "Failed to place order")
            }
        }
    }

    // POS Cart Controls
    fun addToPosCart(product: Product, quantity: Double = 1.0) {
        val current = _posCart.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == product.id }
        if (idx >= 0) {
            val existing = current[idx]
            current[idx] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            current.add(PosCartEntry(product, quantity))
        }
        _posCart.value = current
    }

    fun updatePosCartQuantity(productId: Long, newQuantity: Double) {
        val current = _posCart.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == productId }
        if (idx >= 0) {
            if (newQuantity <= 0.0) {
                current.removeAt(idx)
            } else {
                current[idx] = current[idx].copy(quantity = newQuantity)
            }
        }
        _posCart.value = current
    }

    fun removePosCartItem(productId: Long) {
        _posCart.value = _posCart.value.filter { it.product.id != productId }
    }

    fun clearPosCart() {
        _posCart.value = emptyList()
        _posSelectedCustomer.value = null
        _posOverallDiscount.value = 0.0
    }

    fun setPosCustomer(customer: Customer?) {
        _posSelectedCustomer.value = customer
    }

    fun setPosOverallDiscount(discount: Double) {
        _posOverallDiscount.value = discount
    }

    fun completePosSale(
        paymentMethod: PaymentMethod,
        notes: String = "",
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        val entries = _posCart.value
        if (entries.isEmpty()) {
            onError("POS Cart is empty")
            return
        }
        val cartItems = entries.map { CartItem(it.product, it.quantity) }
        val subtotal = entries.sumOf { (it.product.sellingPrice - it.unitDiscount) * it.quantity }
        val discount = _posOverallDiscount.value
        val settings = shopSettings.value
        val tax = if (settings?.isTaxEnabled == true) (subtotal - discount) * (settings.taxPercentage / 100.0) else 0.0
        val total = max(0.0, subtotal - discount + tax)

        viewModelScope.launch {
            val res = repository.processOfflineSale(
                cartItems = cartItems,
                customer = _posSelectedCustomer.value,
                cashierName = _currentOperatorName.value,
                subtotal = subtotal,
                discount = discount,
                tax = tax,
                totalAmount = total,
                paymentMethod = paymentMethod,
                notes = notes
            )
            res.onSuccess { saleId ->
                clearPosCart()
                onSuccess(saleId)
            }.onFailure { err ->
                onError(err.message ?: "Failed to process sale")
            }
        }
    }

    // Order status actions
    fun updateOrderStatus(orderId: Long, status: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status, _currentOperatorName.value)
        }
    }

    fun assignDelivery(orderId: Long, staffId: Long, staffName: String) {
        viewModelScope.launch {
            repository.assignDeliveryStaff(orderId, staffId, staffName, _currentOperatorName.value)
        }
    }

    // Stock Actions
    fun recordStockIn(
        supplier: Supplier,
        invoiceNumber: String,
        items: List<PurchaseOrderItem>,
        paymentMethod: PaymentMethod,
        notes: String = "",
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.recordPurchaseOrder(
                supplier = supplier,
                invoiceNumber = invoiceNumber,
                items = items,
                paymentMethod = paymentMethod,
                operatorName = _currentOperatorName.value,
                notes = notes
            )
            onSuccess()
        }
    }

    fun adjustStock(
        productId: Long,
        quantityChange: Double,
        movementType: MovementType,
        reason: String
    ) {
        viewModelScope.launch {
            repository.adjustStock(
                productId = productId,
                adjustmentQuantity = quantityChange,
                movementType = movementType,
                reason = reason,
                operatorName = _currentOperatorName.value
            )
        }
    }

    // Cash register actions
    fun openRegister(openingCash: Double) {
        viewModelScope.launch {
            repository.openCashRegister(openingCash, _currentOperatorName.value)
        }
    }

    fun closeRegister(sessionId: Long, physicalCash: Double, notes: String) {
        viewModelScope.launch {
            repository.closeCashRegister(sessionId, physicalCash, notes, _currentOperatorName.value)
        }
    }

    fun addManualCash(type: com.example.data.model.CashTransactionType, amount: Double, isCredit: Boolean, description: String) {
        viewModelScope.launch {
            repository.recordManualCashMovement(type, amount, isCredit, description, _currentOperatorName.value)
        }
    }

    fun addExpense(
        category: ExpenseCategory,
        amount: Double,
        paymentMethod: PaymentMethod,
        description: String,
        receiptNote: String = ""
    ) {
        viewModelScope.launch {
            repository.addExpense(
                category = category,
                amount = amount,
                paymentMethod = paymentMethod,
                description = description,
                addedBy = _currentOperatorName.value,
                receiptNote = receiptNote
            )
        }
    }

    fun saveProduct(product: Product) {
        viewModelScope.launch {
            repository.saveProduct(product, _currentOperatorName.value)
        }
    }

    fun deleteProduct(productId: Long) {
        viewModelScope.launch {
            repository.deleteProduct(productId, _currentOperatorName.value)
        }
    }

    fun saveEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.saveEmployee(employee, _currentOperatorName.value)
        }
    }

    fun deleteEmployee(id: Long) {
        viewModelScope.launch {
            repository.deleteEmployee(id, _currentOperatorName.value)
        }
    }

    fun saveCustomer(customer: Customer, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createOrUpdateCustomer(customer)
            onSaved(id)
        }
    }

    fun addCustomerAddress(address: CustomerAddress) {
        viewModelScope.launch {
            repository.addCustomerAddress(address)
        }
    }

    fun updateSettings(settings: ShopSettings) {
        viewModelScope.launch {
            repository.updateSettings(settings, _currentOperatorName.value)
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markNotificationAsRead(id) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch { repository.markAllNotificationsAsRead() }
    }

    // Filter controls
    fun setProductSearch(query: String) { _productSearchQuery.value = query }
    fun setCategoryFilter(catId: Long?) { _selectedCategoryId.value = catId }
    fun setOrderStatusFilter(status: OrderStatus?) { _orderStatusFilter.value = status }
    fun setAnalyticsTimeRange(range: AnalyticsTimeRange) { _analyticsTimeRange.value = range }

    // Analytics Calculation Algorithm
    private fun calculateAnalytics(
        orders: List<Order>,
        orderItems: List<OrderItem>,
        sales: List<OfflineSale>,
        saleItems: List<OfflineSaleItem>,
        expenses: List<Expense>,
        range: AnalyticsTimeRange
    ): SalesAnalyticsSummary {
        val now = Calendar.getInstance()
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val (startTime, endTime) = when (range) {
            AnalyticsTimeRange.TODAY -> Pair(startOfToday, Long.MAX_VALUE)
            AnalyticsTimeRange.YESTERDAY -> {
                val yesterdayStart = startOfToday - 86400000L
                Pair(yesterdayStart, startOfToday - 1)
            }
            AnalyticsTimeRange.THIS_WEEK -> {
                val weekStart = startOfToday - 86400000L * 6
                Pair(weekStart, Long.MAX_VALUE)
            }
            AnalyticsTimeRange.THIS_MONTH -> {
                val monthStart = startOfToday - 86400000L * 30
                Pair(monthStart, Long.MAX_VALUE)
            }
            AnalyticsTimeRange.ALL_TIME -> Pair(0L, Long.MAX_VALUE)
        }

        val filteredOrders = orders.filter { it.createdAt in startTime..endTime && it.orderStatus != OrderStatus.CANCELLED }
        val filteredSales = sales.filter { it.createdAt in startTime..endTime && !it.isVoided }
        val filteredExpenses = expenses.filter { it.date in startTime..endTime }

        val onlineRevenue = filteredOrders.sumOf { it.totalAmount }
        val offlineRevenue = filteredSales.sumOf { it.totalAmount }
        val totalRevenue = onlineRevenue + offlineRevenue

        // Calculate Cost of Goods Sold (COGS)
        val validOrderIds = filteredOrders.map { it.id }.toSet()
        val validSaleIds = filteredSales.map { it.id }.toSet()

        val filteredOrderItems = orderItems.filter { it.orderId in validOrderIds }
        val filteredSaleItems = saleItems.filter { it.saleId in validSaleIds }

        val orderCost = filteredOrderItems.sumOf { it.costPrice * it.quantity }
        val saleCost = filteredSaleItems.sumOf { it.costPrice * it.quantity }
        val totalCostOfGoods = orderCost + saleCost

        val grossProfit = max(0.0, totalRevenue - totalCostOfGoods)
        val totalExpenses = filteredExpenses.sumOf { it.amount }
        val netProfit = grossProfit - totalExpenses

        val totalTransactions = filteredOrders.size + filteredSales.size
        val avgOrderValue = if (totalTransactions > 0) totalRevenue / totalTransactions else 0.0

        val cashSales = filteredOrders.filter { it.paymentMethod == PaymentMethod.CASH || it.paymentMethod == PaymentMethod.CASH_AT_PICKUP }.sumOf { it.totalAmount } +
                filteredSales.filter { it.paymentMethod == PaymentMethod.CASH }.sumOf { it.totalAmount }

        val upiSales = filteredOrders.filter { it.paymentMethod == PaymentMethod.UPI }.sumOf { it.totalAmount } +
                filteredSales.filter { it.paymentMethod == PaymentMethod.UPI }.sumOf { it.totalAmount }

        val cardSales = filteredOrders.filter { it.paymentMethod == PaymentMethod.CARD }.sumOf { it.totalAmount } +
                filteredSales.filter { it.paymentMethod == PaymentMethod.CARD }.sumOf { it.totalAmount }

        // Product popularity
        val productQuantities = mutableMapOf<String, Double>()
        filteredOrderItems.forEach { productQuantities[it.productName] = (productQuantities[it.productName] ?: 0.0) + it.quantity }
        filteredSaleItems.forEach { productQuantities[it.productName] = (productQuantities[it.productName] ?: 0.0) + it.quantity }
        val bestSellers = productQuantities.toList().sortedByDescending { it.second }.take(5)

        return SalesAnalyticsSummary(
            totalRevenue = totalRevenue,
            totalCostOfGoods = totalCostOfGoods,
            grossProfit = grossProfit,
            totalExpenses = totalExpenses,
            netProfit = netProfit,
            totalTransactionsCount = totalTransactions,
            onlineOrdersCount = filteredOrders.size,
            offlineSalesCount = filteredSales.size,
            cashSalesAmount = cashSales,
            upiSalesAmount = upiSales,
            cardSalesAmount = cardSales,
            averageOrderValue = avgOrderValue,
            bestSellingProducts = bestSellers
        )
    }
}
