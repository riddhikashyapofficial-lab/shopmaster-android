package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class CashTransactionType(val displayName: String) {
    OPENING_BALANCE("Opening Balance"),
    CASH_SALE_POS("POS Cash Sale"),
    COD_DELIVERY("COD Delivery Collected"),
    PICKUP_PAYMENT("Shop Pickup Cash"),
    EXPENSE_PAID("Cash Expense"),
    WITHDRAWAL("Cash Withdrawal"),
    ADDITION("Cash Added"),
    REFUND("Refund Paid")
}

@Entity(tableName = "cash_register_sessions")
data class CashRegisterSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val openedAt: Long = System.currentTimeMillis(),
    val closedAt: Long? = null,
    val openedBy: String = "Admin",
    val closedBy: String? = null,
    val openingCash: Double = 5000.0,
    val totalCashSales: Double = 0.0,
    val totalCodCollected: Double = 0.0,
    val totalPickupCashCollected: Double = 0.0,
    val totalCashExpenses: Double = 0.0,
    val totalCashWithdrawals: Double = 0.0,
    val totalCashAdditions: Double = 0.0,
    val totalRefunds: Double = 0.0,
    val expectedClosingCash: Double = 5000.0,
    val actualPhysicalCash: Double? = null,
    val discrepancy: Double? = null,
    val discrepancyNotes: String = "",
    val isClosed: Boolean = false
)

@Entity(
    tableName = "cash_transactions",
    indices = [Index(value = ["sessionId"]), Index(value = ["timestamp"])]
)
data class CashTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val type: CashTransactionType,
    val amount: Double,
    val isCredit: Boolean, // true for incoming cash, false for outgoing
    val description: String,
    val referenceId: String = "",
    val operatorName: String = "Staff",
    val timestamp: Long = System.currentTimeMillis()
)

enum class ExpenseCategory(val displayName: String) {
    RENT("Shop Rent"),
    ELECTRICITY("Electricity & Utilities"),
    TRANSPORTATION("Transportation & Fuel"),
    PACKAGING("Packaging & Bags"),
    SALARY("Employee Salaries"),
    REPAIRS("Repairs & Maintenance"),
    PURCHASES("Shop Purchases"),
    OTHER("Other Miscellaneous")
}

@Entity(tableName = "expenses", indices = [Index(value = ["date"])])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: ExpenseCategory,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val description: String,
    val addedBy: String = "Owner",
    val receiptNote: String = ""
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val contactPerson: String = "",
    val phone: String,
    val email: String = "",
    val address: String = "",
    val gstNumber: String = ""
)

@Entity(tableName = "purchase_orders", indices = [Index(value = ["supplierId"]), Index(value = ["date"])])
data class PurchaseOrder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val supplierId: Long,
    val supplierName: String,
    val date: Long = System.currentTimeMillis(),
    val totalAmount: Double,
    val paymentStatus: PaymentStatus = PaymentStatus.PAID,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val notes: String = "",
    val createdBy: String = "Owner"
)

@Entity(
    tableName = "purchase_order_items",
    foreignKeys = [
        ForeignKey(
            entity = PurchaseOrder::class,
            parentColumns = ["id"],
            childColumns = ["purchaseOrderId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["purchaseOrderId"]), Index(value = ["productId"])]
)
data class PurchaseOrderItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseOrderId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val purchasePrice: Double,
    val total: Double
)

@Entity(tableName = "audit_logs", indices = [Index(value = ["timestamp"])])
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userName: String,
    val userRole: UserRole,
    val action: String,
    val itemType: String,
    val itemId: String = "",
    val details: String,
    val previousValue: String = "",
    val newValue: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

enum class NotificationType {
    ORDER, STOCK_ALERT, CASH_ALERT, DELIVERY, GENERAL
}

@Entity(tableName = "app_notifications", indices = [Index(value = ["timestamp"])])
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val type: NotificationType = NotificationType.GENERAL,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "shop_settings")
data class ShopSettings(
    @PrimaryKey val id: Long = 1,
    val shopName: String = "FreshMart Super Store",
    val logoUrl: String = "",
    val address: String = "Shop No. 4, Market Complex, Main Road",
    val phone: String = "+91 98765 43210",
    val email: String = "contact@freshmart.local",
    val openingHours: String = "8:00 AM - 10:00 PM",
    val deliveryCharge: Double = 30.0,
    val minOrderValue: Double = 150.0,
    val freeDeliveryThreshold: Double = 500.0,
    val isDeliveryEnabled: Boolean = true,
    val isPickupEnabled: Boolean = true,
    val isOnlinePaymentEnabled: Boolean = true,
    val isTaxEnabled: Boolean = true,
    val taxPercentage: Double = 5.0,
    val lowStockDefaultThreshold: Double = 5.0,
    val regularCustomerOrderThreshold: Int = 5,
    val regularCustomerDaysWindow: Int = 30,
    val currencySymbol: String = "₹",
    val invoiceHeader: String = "Thank you for shopping with us!",
    val invoiceFooter: String = "For support or home orders, call: +91 98765 43210"
)
