package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class CustomerRepeatTier(val label: String, val badgeColorHex: Long) {
    NEW("New Customer", 0xFF3B82F6),
    RETURNING("Returning Customer", 0xFF10B981),
    REGULAR("Regular Customer", 0xFF8B5CF6),
    OCCASIONAL("Occasional Customer", 0xFFF59E0B),
    INACTIVE("Inactive Customer", 0xFF94A3B8)
}

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String = "",
    val address: String = "",
    val totalPurchases: Int = 0,
    val onlinePurchases: Int = 0,
    val offlinePurchases: Int = 0,
    val totalAmountSpent: Double = 0.0,
    val averagePurchaseValue: Double = 0.0,
    val lastPurchaseDate: Long? = null,
    val customerSince: Long = System.currentTimeMillis(),
    val notes: String = "",
    val repeatTier: CustomerRepeatTier = CustomerRepeatTier.NEW
)

@Entity(
    tableName = "customer_addresses",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["customerId"])]
)
data class CustomerAddress(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val label: String = "Home", // Home, Work, Other
    val streetAddress: String,
    val landmark: String = "",
    val city: String = "Local Area",
    val pinCode: String = "",
    val phone: String = "",
    val isDefault: Boolean = false
)
