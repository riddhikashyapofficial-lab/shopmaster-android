package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.Customer
import com.example.data.model.CustomerAddress
import com.example.data.model.OfflineSale
import com.example.data.model.OfflineSaleItem
import com.example.data.model.Order
import com.example.data.model.OrderItem
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY totalAmountSpent DESC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Long): Customer?

    @Query("SELECT * FROM customers WHERE phone = :phone LIMIT 1")
    suspend fun getCustomerByPhone(phone: String): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCustomers(customers: List<Customer>)

    @Update
    suspend fun updateCustomer(customer: Customer)

    // Customer Addresses
    @Query("SELECT * FROM customer_addresses WHERE customerId = :customerId")
    fun getCustomerAddresses(customerId: Long): Flow<List<CustomerAddress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddress(address: CustomerAddress): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAddresses(addresses: List<CustomerAddress>)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getOrdersByCustomer(customerId: Long): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE orderStatus = :status ORDER BY createdAt DESC")
    fun getOrdersByStatus(status: OrderStatus): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE assignedDeliveryStaffId = :staffId ORDER BY createdAt DESC")
    fun getAssignedDeliveryOrders(staffId: Long): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: Long): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllOrders(orders: List<Order>)

    @Update
    suspend fun updateOrder(order: Order)

    @Query("UPDATE orders SET orderStatus = :status, updatedAt = :updatedAt WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Long, status: OrderStatus, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE orders SET paymentStatus = :paymentStatus, updatedAt = :updatedAt WHERE id = :orderId")
    suspend fun updatePaymentStatus(orderId: Long, paymentStatus: PaymentStatus, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE orders SET assignedDeliveryStaffId = :staffId, assignedDeliveryStaffName = :staffName, updatedAt = :updatedAt WHERE id = :orderId")
    suspend fun assignDeliveryStaff(orderId: Long, staffId: Long?, staffName: String, updatedAt: Long = System.currentTimeMillis())

    // Order Items
    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItems(orderId: Long): Flow<List<OrderItem>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getOrderItemsList(orderId: Long): List<OrderItem>

    @Query("SELECT * FROM order_items")
    fun getAllOrderItems(): Flow<List<OrderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItem>)
}

@Dao
interface OfflineSaleDao {
    @Query("SELECT * FROM offline_sales ORDER BY createdAt DESC")
    fun getAllSales(): Flow<List<OfflineSale>>

    @Query("SELECT * FROM offline_sales WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getSalesByCustomer(customerId: Long): Flow<List<OfflineSale>>

    @Query("SELECT * FROM offline_sales WHERE id = :id")
    suspend fun getSaleById(id: Long): OfflineSale?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: OfflineSale): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSales(sales: List<OfflineSale>)

    @Update
    suspend fun updateSale(sale: OfflineSale)

    // Sale Items
    @Query("SELECT * FROM offline_sale_items WHERE saleId = :saleId")
    fun getSaleItems(saleId: Long): Flow<List<OfflineSaleItem>>

    @Query("SELECT * FROM offline_sale_items WHERE saleId = :saleId")
    suspend fun getSaleItemsList(saleId: Long): List<OfflineSaleItem>

    @Query("SELECT * FROM offline_sale_items")
    fun getAllSaleItems(): Flow<List<OfflineSaleItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleItems(items: List<OfflineSaleItem>)
}
