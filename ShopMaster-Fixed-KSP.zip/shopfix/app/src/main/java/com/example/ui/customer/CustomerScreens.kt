package com.example.ui.customer

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.DeliveryType
import com.example.data.model.Order
import com.example.data.model.OrderItem
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.UserRole
import com.example.ui.ShopViewModel
import com.example.ui.components.CustomerTierBadge
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.OrderTimelineTracker
import com.example.ui.components.QuantityStepper
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.components.formatDateTime
import com.example.ui.components.getCategoryVisualIcon
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.FreshGreenPrimary
import com.example.ui.theme.FreshGreenPrimaryDark
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.GoldenAmberLight
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import com.example.ui.theme.WarmPeachBackground
import com.example.ui.theme.WarmPeachBorder
import com.example.ui.theme.WarmPeachContainer
import com.example.ui.theme.WarmPeachSurface
import com.example.ui.theme.WarmPeachSurfaceVariant
import com.example.ui.theme.WarmSlateDark
import com.example.ui.theme.WarmSlateMuted
import com.example.ui.theme.WarmSlateText
import kotlinx.coroutines.launch

/**
 * Modern, Premium Mobile Shopping App Experience with Warm Peach / Soft Golden Background
 * and Clean Floating White Cards with Fresh Green Accents.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerMainScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    var customerNavTab by remember { mutableStateOf("home") } // "home", "categories", "search", "cart", "orders", "account"
    var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }
    var showCartSheet by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var showStaffRolePicker by remember { mutableStateOf(false) }
    var selectedOrderForTracking by remember { mutableStateOf<Order?>(null) }

    val cart by viewModel.customerCart.collectAsState()
    val totalCartItems = cart.values.sumOf { it.quantity }
    val cartSubtotal = cart.values.sumOf { it.product.sellingPrice * it.quantity }
    val settings by viewModel.shopSettings.collectAsState()
    val allCustomers by viewModel.customers.collectAsState()
    val activeCustomer by viewModel.activeCustomer.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        WarmPeachBackground,
                        Color(0xFFFFF4E8),
                        Color(0xFFFEEDDB)
                    )
                )
            )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                CustomerTopHeader(
                    shopName = settings?.shopName ?: "FreshMart Super Store",
                    shopAddress = settings?.address ?: "Local Market Store",
                    activeCustomer = activeCustomer,
                    onSwitchProfile = { showCustomerPicker = true },
                    onSwitchRole = { showStaffRolePicker = true }
                )
            },
            bottomBar = {
                // App-like Modern Bottom Navigation Bar
                Surface(
                    color = WarmPeachSurface,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    shadowElevation = 12.dp,
                    border = BorderStroke(1.dp, WarmPeachBorder)
                ) {
                    NavigationBar(
                        containerColor = Color.Transparent,
                        tonalElevation = 0.dp
                    ) {
                        NavigationBarItem(
                            selected = customerNavTab == "home",
                            onClick = { customerNavTab = "home" },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Shop", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_home")
                        )
                        NavigationBarItem(
                            selected = customerNavTab == "categories",
                            onClick = { customerNavTab = "categories" },
                            icon = { Icon(Icons.Default.GridView, contentDescription = "Categories") },
                            label = { Text("Categories", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_categories")
                        )
                        NavigationBarItem(
                            selected = customerNavTab == "search",
                            onClick = { customerNavTab = "search" },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                            label = { Text("Search", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_search")
                        )
                        NavigationBarItem(
                            selected = customerNavTab == "cart",
                            onClick = { showCartSheet = true },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (totalCartItems > 0) {
                                            Badge(containerColor = FreshGreenPrimary) {
                                                Text(
                                                    text = if (totalCartItems % 1.0 == 0.0) totalCartItems.toInt().toString() else "%.0f".format(totalCartItems),
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                                }
                            },
                            label = { Text("Cart", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_cart")
                        )
                        NavigationBarItem(
                            selected = customerNavTab == "orders",
                            onClick = { customerNavTab = "orders" },
                            icon = { Icon(Icons.Default.Receipt, contentDescription = "Orders") },
                            label = { Text("Orders", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_orders")
                        )
                        NavigationBarItem(
                            selected = customerNavTab == "account",
                            onClick = { customerNavTab = "account" },
                            icon = { Icon(Icons.Default.Person, contentDescription = "Account") },
                            label = { Text("Account", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = FreshGreenContainer,
                                selectedIconColor = FreshGreenPrimary,
                                selectedTextColor = FreshGreenPrimary
                            ),
                            modifier = Modifier.testTag("nav_cust_account")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (customerNavTab) {
                    "home" -> CustomerHomeStorefront(
                        viewModel = viewModel,
                        onProductClick = { selectedProductForDetail = it },
                        onExploreCategories = { customerNavTab = "categories" },
                        onViewCart = { showCartSheet = true }
                    )
                    "categories" -> CustomerCategoriesScreen(
                        viewModel = viewModel,
                        onProductClick = { selectedProductForDetail = it }
                    )
                    "search" -> CustomerSearchScreen(
                        viewModel = viewModel,
                        onProductClick = { selectedProductForDetail = it }
                    )
                    "orders" -> CustomerOrdersView(
                        viewModel = viewModel,
                        onTrackOrder = { selectedOrderForTracking = it },
                        onReorder = { orderItems ->
                            orderItems.forEach { item ->
                                val prod = viewModel.products.value.find { it.id == item.productId }
                                if (prod != null && prod.currentStock > 0) {
                                    viewModel.addToCustomerCart(prod, item.quantity)
                                }
                            }
                            showCartSheet = true
                        }
                    )
                    "account" -> CustomerProfileView(viewModel = viewModel)
                }

                // Sticky Floating Cart Bar (Appears when cart has items)
                if (totalCartItems > 0 && !showCartSheet) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth()
                            .widthIn(max = 500.dp)
                    ) {
                        Surface(
                            onClick = { showCartSheet = true },
                            color = FreshGreenPrimary,
                            shape = RoundedCornerShape(20.dp),
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("floating_cart_bar")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val countStr = if (totalCartItems % 1.0 == 0.0) totalCartItems.toInt().toString() else "%.0f".format(totalCartItems)
                                        Text(
                                            text = countStr,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "View Cart",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = formatCurrency(cartSubtotal, currency),
                                            color = Color.White.copy(alpha = 0.9f),
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Checkout",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        Icons.Default.ArrowForward,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Product Detail Sheet
    selectedProductForDetail?.let { prod ->
        CustomerProductDetailSheet(
            product = prod,
            currency = currency,
            onDismiss = { selectedProductForDetail = null },
            onAddToCart = { qty ->
                viewModel.addToCustomerCart(prod, qty)
                selectedProductForDetail = null
            }
        )
    }

    // Cart and Checkout Sheet
    if (showCartSheet) {
        CustomerCartSheet(
            viewModel = viewModel,
            onDismiss = { showCartSheet = false },
            onOrderPlaced = { orderId ->
                showCartSheet = false
                customerNavTab = "orders"
            }
        )
    }

    // Customer Profile Switcher Modal
    if (showCustomerPicker) {
        CustomerPickerModal(
            customers = allCustomers,
            currentCustomer = activeCustomer,
            onSelect = {
                viewModel.setActiveCustomer(it)
                showCustomerPicker = false
            },
            onDismiss = { showCustomerPicker = false }
        )
    }

    // Order Tracking Modal
    selectedOrderForTracking?.let { order ->
        OrderTrackingModal(
            order = order,
            viewModel = viewModel,
            onDismiss = { selectedOrderForTracking = null }
        )
    }

    // Role Switcher Modal (to switch to Staff/Owner/Manager/Cashier/Delivery)
    if (showStaffRolePicker) {
        val sheetState = rememberModalBottomSheetState()
        ModalBottomSheet(
            onDismissRequest = { showStaffRolePicker = false },
            sheetState = sheetState,
            containerColor = WarmPeachSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Switch Mode / Role",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = WarmSlateDark
                )
                Text(
                    text = "Select a management or staff role to enter back-office POS & Inventory",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmSlateMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                for (role in UserRole.entries) {
                    Surface(
                        onClick = {
                            viewModel.setCurrentRole(role)
                            showStaffRolePicker = false
                        },
                        shape = RoundedCornerShape(16.dp),
                        color = if (role == UserRole.CUSTOMER) WarmPeachSurfaceVariant else Color.White,
                        border = BorderStroke(1.dp, if (role == UserRole.CUSTOMER) FreshGreenPrimary else WarmPeachBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (role) {
                                    UserRole.CUSTOMER -> "🛒"
                                    UserRole.OWNER -> "👑"
                                    UserRole.MANAGER -> "💼"
                                    UserRole.CASHIER -> "💳"
                                    UserRole.STOCK_STAFF -> "📦"
                                    UserRole.DELIVERY_STAFF -> "🛵"
                                },
                                fontSize = 24.sp
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (role == UserRole.CUSTOMER) "Customer Mode (Storefront)" else "${role.displayName} Mode",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = WarmSlateDark
                                )
                                Text(
                                    text = when (role) {
                                        UserRole.CUSTOMER -> "Online ordering & digital catalog"
                                        UserRole.OWNER -> "Full administration, analytics & settings"
                                        UserRole.MANAGER -> "POS billing, inventory & orders"
                                        UserRole.CASHIER -> "Fast in-store POS checkout"
                                        UserRole.STOCK_STAFF -> "Stock auditing & barcode scanner"
                                        UserRole.DELIVERY_STAFF -> "Active delivery runs & status updates"
                                    },
                                    fontSize = 12.sp,
                                    color = WarmSlateMuted
                                )
                            }
                            if (role == UserRole.CUSTOMER) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Active",
                                    tint = FreshGreenPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}

/**
 * Top Header Bar for Customer Storefront
 */
@Composable
fun CustomerTopHeader(
    shopName: String,
    shopAddress: String,
    activeCustomer: Customer?,
    onSwitchProfile: () -> Unit,
    onSwitchRole: () -> Unit
) {
    Surface(
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                // Shop Logo Avatar
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(FreshGreenPrimary)
                        .shadow(4.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🛒",
                        fontSize = 20.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = shopName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmSlateDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = FreshGreenPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = shopAddress,
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmSlateMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                // Switch to Staff POS/Management button
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = FreshGreenContainer,
                    border = BorderStroke(1.dp, FreshGreenPrimary.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clickable { onSwitchRole() }
                        .testTag("customer_switch_staff_mode")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Store,
                            contentDescription = null,
                            tint = FreshGreenPrimaryDark,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Staff POS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FreshGreenPrimaryDark
                        )
                    }
                }

                // Customer Profile Pill Button
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = WarmPeachSurface,
                    border = BorderStroke(1.dp, WarmPeachBorder),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .clickable { onSwitchProfile() }
                        .testTag("customer_profile_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(FreshGreenPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (activeCustomer?.name?.firstOrNull() ?: 'C').toString(),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeCustomer?.name?.split(" ")?.firstOrNull() ?: "Guest",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = WarmSlateDark
                        )
                    }
                }
            }
        }
    }
}

/**
 * Customer Home Storefront with Hero Section, Floating Cards Composition, Category Chips, and Product Grid
 */
@Composable
fun CustomerHomeStorefront(
    viewModel: ShopViewModel,
    onProductClick: (Product) -> Unit,
    onExploreCategories: () -> Unit,
    onViewCart: () -> Unit
) {
    val categories by viewModel.categories.collectAsState()
    val products by viewModel.filteredProducts.collectAsState()
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()
    val cart by viewModel.customerCart.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // HERO SECTION WITH FLOATING MULTI-SCREEN COMPOSITION
        item {
            CustomerHeroSection(
                onShopNow = { viewModel.setCategoryFilter(null) },
                onExploreCategories = onExploreCategories,
                currency = currency
            )
        }

        // CATEGORY SECTION (Horizontal Chips)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Shop by Category",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmSlateDark
                    )
                    Text(
                        text = "View All",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = FreshGreenPrimary,
                        modifier = Modifier
                            .clickable { onExploreCategories() }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        CategoryPillCard(
                            title = "All Products",
                            iconEmoji = "🛒",
                            isSelected = selectedCatId == null,
                            onClick = { viewModel.setCategoryFilter(null) }
                        )
                    }
                    items(categories) { cat ->
                        CategoryPillCard(
                            title = cat.name,
                            iconEmoji = getCategoryVisualIcon(cat.name),
                            isSelected = selectedCatId == cat.id,
                            onClick = { viewModel.setCategoryFilter(if (selectedCatId == cat.id) null else cat.id) }
                        )
                    }
                }
            }
        }

        // PROMOTIONAL BANNER CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = FreshGreenContainer
                ),
                border = BorderStroke(1.dp, FreshGreenPrimary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⚡", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Free Express Delivery",
                                fontWeight = FontWeight.Bold,
                                color = OnFreshGreenContainer,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "On all orders above ${formatCurrency(settings?.freeDeliveryThreshold ?: 500.0, currency)} • Direct from local store",
                            fontSize = 12.sp,
                            color = OnFreshGreenContainer.copy(alpha = 0.85f)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(FreshGreenPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.DeliveryDining,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        // PRODUCT SECTION HEADER
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedCatId == null) "Fresh Everyday Essentials" else "Category Products",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = WarmSlateDark
                )
                Text(
                    text = "${products.size} Items",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmSlateMuted
                )
            }
        }

        // PRODUCTS GRID (2 Columns mobile, adaptive on tablet)
        if (products.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🥦", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No products in this category yet.", fontWeight = FontWeight.SemiBold, color = WarmSlateDark)
                    }
                }
            }
        } else {
            // Render products in 2-column rows for beautiful mobile flow
            val chunked = products.chunked(2)
            items(chunked) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val p1 = pair[0]
                    val cartItem1 = cart[p1.id]
                    Box(modifier = Modifier.weight(1f)) {
                        CustomerProductCard(
                            product = p1,
                            cartQuantity = cartItem1?.quantity ?: 0.0,
                            currency = currency,
                            onClick = { onProductClick(p1) },
                            onAddToCart = { viewModel.addToCustomerCart(p1, 1.0) },
                            onUpdateQuantity = { q -> viewModel.updateCustomerCartQuantity(p1.id, q) }
                        )
                    }

                    if (pair.size > 1) {
                        val p2 = pair[1]
                        val cartItem2 = cart[p2.id]
                        Box(modifier = Modifier.weight(1f)) {
                            CustomerProductCard(
                                product = p2,
                                cartQuantity = cartItem2?.quantity ?: 0.0,
                                currency = currency,
                                onClick = { onProductClick(p2) },
                                onAddToCart = { viewModel.addToCustomerCart(p2, 1.0) },
                                onUpdateQuantity = { q -> viewModel.updateCustomerCartQuantity(p2.id, q) }
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/**
 * Visually Striking Hero Section with Left Content & Right Floating Mobile Screens Composition
 */
@Composable
fun CustomerHeroSection(
    onShopNow: () -> Unit,
    onExploreCategories: () -> Unit,
    currency: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
            border = BorderStroke(1.dp, WarmPeachBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Label Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = WarmPeachContainer,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🌿", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "YOUR LOCAL SHOP, NOW ONLINE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FreshGreenPrimaryDark
                        )
                    }
                }

                // Main Bold Headline
                Text(
                    text = "Everything You Need.\nRight From Your Local Shop.",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = WarmSlateDark,
                    lineHeight = 32.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Short Subtitle Description
                Text(
                    text = "Fresh products, everyday essentials and more — delivered to your doorstep or ready for instant pickup.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmSlateMuted,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Action CTAs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onShopNow,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("hero_shop_now_btn")
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Shop Now", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    OutlinedButton(
                        onClick = onExploreCategories,
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.5.dp, FreshGreenPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("hero_explore_cat_btn")
                    ) {
                        Text("Categories", fontWeight = FontWeight.Bold, color = FreshGreenPrimary, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Floating Mobile Screens Composition Inspired by Reference
                FloatingCardsShowcase(currency = currency)
            }
        }
    }
}

/**
 * Floating rounded mobile-style product cards/screens composition
 */
@Composable
fun FloatingCardsShowcase(currency: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFFFEF3E2),
                        Color(0xFFFEEDDB),
                        Color(0xFFFDE1C8)
                    )
                )
            )
            .padding(12.dp)
    ) {
        // Back Layer Floating Card (Mini Catalogue Screen)
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WarmPeachSurface.copy(alpha = 0.85f),
            shadowElevation = 4.dp,
            border = BorderStroke(1.dp, WarmPeachBorder),
            modifier = Modifier
                .width(160.dp)
                .height(130.dp)
                .offset(x = 10.dp, y = 8.dp)
                .rotate(-4f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(18.dp).clip(CircleShape).background(FreshGreenPrimary))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Store Catalog", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("🍎 Fruits", fontSize = 9.sp, color = WarmSlateMuted)
                    Text("🥛 Dairy", fontSize = 9.sp, color = WarmSlateMuted)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(WarmPeachContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⚡ Quick 30m Run", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = FreshGreenPrimaryDark)
                }
            }
        }

        // Front Layer Floating Product Card ("Fresh Apples 1kg ₹180 [-] 2 [+]")
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WarmPeachSurface,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, WarmPeachBorder),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(175.dp)
                .offset(x = (-6).dp, y = 4.dp)
                .rotate(3f)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🍎", fontSize = 22.sp)
                    Surface(shape = RoundedCornerShape(10.dp), color = FreshGreenContainer) {
                        Text("In Stock", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = FreshGreenPrimary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text("Fresh Apples", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                Text("1 kg • $currency 180", fontSize = 10.sp, color = WarmSlateMuted)
                Spacer(modifier = Modifier.height(6.dp))

                // Mini Green Stepper
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = FreshGreenPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("2", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Bottom Left Floating Order Badge
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = WarmPeachSurface,
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, WarmPeachBorder),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = 18.dp, y = (-4).dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FreshGreenPrimary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Order #1042 Delivered", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = WarmSlateDark)
            }
        }
    }
}

/**
 * Category Pill Card for Horizontal Scroller
 */
@Composable
fun CategoryPillCard(
    title: String,
    iconEmoji: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = if (isSelected) FreshGreenPrimary else WarmPeachSurface,
        border = if (isSelected) null else BorderStroke(1.dp, WarmPeachBorder),
        shadowElevation = if (isSelected) 4.dp else 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(iconEmoji, fontSize = 16.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else WarmSlateDark
            )
        }
    }
}

/**
 * Clean White Product Card with Large Rounded Corners and Green Stepper
 */
@Composable
fun CustomerProductCard(
    product: Product,
    cartQuantity: Double,
    currency: String,
    onClick: () -> Unit,
    onAddToCart: () -> Unit,
    onUpdateQuantity: (Double) -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
        border = BorderStroke(1.dp, WarmPeachBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("product_card_${product.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Top Product Visual Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                WarmPeachSurfaceVariant,
                                Color(0xFFF9EDE0)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Food / Product Emoji or Badge
                Text(
                    text = getCategoryVisualIcon(product.name),
                    fontSize = 44.sp
                )

                // Stock Badge on Top-Right
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    if (product.currentStock <= 0.0) {
                        StatusBadge("Out of Stock", StatusErrorBg, StatusError)
                    } else if (product.currentStock <= product.minStockLevel) {
                        StatusBadge("Only ${product.currentStock.toInt()} left", StatusWarningBg, StatusWarning)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Product Name
            Text(
                text = product.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = WarmSlateDark,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                minLines = 2
            )

            Spacer(modifier = Modifier.height(2.dp))

            // Unit / Quantity
            Text(
                text = "1 ${product.unit}",
                style = MaterialTheme.typography.bodySmall,
                color = WarmSlateMuted
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Price & Action Stepper
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatCurrency(product.sellingPrice, currency),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = FreshGreenPrimary
                )

                if (product.currentStock <= 0.0 && !product.allowBackorders) {
                    Text(
                        text = "Out",
                        fontSize = 11.sp,
                        color = StatusError,
                        fontWeight = FontWeight.Bold
                    )
                } else if (cartQuantity > 0.0) {
                    QuantityStepper(
                        quantity = cartQuantity,
                        unit = product.unit,
                        onDecrease = { onUpdateQuantity(cartQuantity - 1.0) },
                        onIncrease = { onUpdateQuantity(cartQuantity + 1.0) }
                    )
                } else {
                    Surface(
                        onClick = onAddToCart,
                        shape = RoundedCornerShape(20.dp),
                        color = FreshGreenPrimary,
                        modifier = Modifier.testTag("add_to_cart_${product.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Add", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Customer Categories Screen
 */
@Composable
fun CustomerCategoriesScreen(
    viewModel: ShopViewModel,
    onProductClick: (Product) -> Unit
) {
    val categories by viewModel.categories.collectAsState()
    val products by viewModel.products.collectAsState()
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()
    val cart by viewModel.customerCart.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Explore All Categories",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = WarmSlateDark
            )
            Text(
                text = "Browse our full range of fresh groceries and essentials",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmSlateMuted
            )
        }

        // Category Cards Grid
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    CategoryPillCard(
                        title = "All",
                        iconEmoji = "🛒",
                        isSelected = selectedCatId == null,
                        onClick = { viewModel.setCategoryFilter(null) }
                    )
                }
                items(categories) { cat ->
                    CategoryPillCard(
                        title = cat.name,
                        iconEmoji = getCategoryVisualIcon(cat.name),
                        isSelected = selectedCatId == cat.id,
                        onClick = { viewModel.setCategoryFilter(cat.id) }
                    )
                }
            }
        }

        val filtered = if (selectedCatId == null) products else products.filter { it.categoryId == selectedCatId }
        items(filtered) { prod ->
            val cartItem = cart[prod.id]
            RowProductRowCard(
                product = prod,
                cartQuantity = cartItem?.quantity ?: 0.0,
                currency = currency,
                onClick = { onProductClick(prod) },
                onAddToCart = { viewModel.addToCustomerCart(prod, 1.0) },
                onUpdateQuantity = { q -> viewModel.updateCustomerCartQuantity(prod.id, q) }
            )
        }
    }
}

/**
 * Customer Search Screen
 */
@Composable
fun CustomerSearchScreen(
    viewModel: ShopViewModel,
    onProductClick: (Product) -> Unit
) {
    val searchQuery by viewModel.productSearchQuery.collectAsState()
    val products by viewModel.filteredProducts.collectAsState()
    val cart by viewModel.customerCart.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setProductSearch(it) },
            placeholder = { Text("Search atta, oil, milk, biscuits, fruits...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = FreshGreenPrimary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setProductSearch("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_search_field")
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = if (searchQuery.isEmpty()) "Popular Products" else "Search Results (${products.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = WarmSlateDark
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(products) { prod ->
                val cartItem = cart[prod.id]
                RowProductRowCard(
                    product = prod,
                    cartQuantity = cartItem?.quantity ?: 0.0,
                    currency = currency,
                    onClick = { onProductClick(prod) },
                    onAddToCart = { viewModel.addToCustomerCart(prod, 1.0) },
                    onUpdateQuantity = { q -> viewModel.updateCustomerCartQuantity(prod.id, q) }
                )
            }
        }
    }
}

/**
 * Horizontal row card for list views
 */
@Composable
fun RowProductRowCard(
    product: Product,
    cartQuantity: Double,
    currency: String,
    onClick: () -> Unit,
    onAddToCart: () -> Unit,
    onUpdateQuantity: (Double) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
        border = BorderStroke(1.dp, WarmPeachBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(WarmPeachSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text(getCategoryVisualIcon(product.name), fontSize = 28.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = WarmSlateDark
                )
                Text(
                    text = "1 ${product.unit}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmSlateMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatCurrency(product.sellingPrice, currency),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = FreshGreenPrimary
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            if (product.currentStock <= 0.0 && !product.allowBackorders) {
                Text("Out of Stock", fontSize = 11.sp, color = StatusError, fontWeight = FontWeight.Bold)
            } else if (cartQuantity > 0.0) {
                QuantityStepper(
                    quantity = cartQuantity,
                    unit = product.unit,
                    onDecrease = { onUpdateQuantity(cartQuantity - 1.0) },
                    onIncrease = { onUpdateQuantity(cartQuantity + 1.0) }
                )
            } else {
                Button(
                    onClick = onAddToCart,
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("Add", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Product Detail Modal Sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerProductDetailSheet(
    product: Product,
    currency: String,
    onDismiss: () -> Unit,
    onAddToCart: (Double) -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var quantity by remember { mutableStateOf(1.0) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = WarmPeachSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(WarmPeachSurfaceVariant, Color(0xFFFEEDDB))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(getCategoryVisualIcon(product.name), fontSize = 64.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = WarmSlateDark
                    )
                    Text(
                        text = "Pack size: 1 ${product.unit} • SKU: ${product.sku.ifBlank { "N/A" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmSlateMuted
                    )
                }
                Text(
                    text = formatCurrency(product.sellingPrice, currency),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = FreshGreenPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = product.description.ifBlank { "Fresh and hand-picked everyday essentials from your trusted local shop." },
                style = MaterialTheme.typography.bodyMedium,
                color = WarmSlateText
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quantity Selection
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Select Quantity", fontWeight = FontWeight.Bold, color = WarmSlateDark)
                QuantityStepper(
                    quantity = quantity,
                    unit = product.unit,
                    onDecrease = { if (quantity > 1.0) quantity -= 1.0 },
                    onIncrease = { quantity += 1.0 }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { onAddToCart(quantity) },
                colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("detail_add_to_cart_btn")
            ) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add to Cart • ${formatCurrency(product.sellingPrice * quantity, currency)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

/**
 * Modern Clean White Rounded Cart & Checkout Panel
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerCartSheet(
    viewModel: ShopViewModel,
    onDismiss: () -> Unit,
    onOrderPlaced: (Long) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cart by viewModel.customerCart.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val activeCustomer by viewModel.activeCustomer.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    var deliveryType by remember { mutableStateOf(DeliveryType.HOME_DELIVERY) }
    var deliveryAddress by remember(activeCustomer) { mutableStateOf(activeCustomer?.address ?: "") }
    var deliveryInstructions by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var isSubmitting by remember { mutableStateOf(false) }

    val subtotal = cart.values.sumOf { it.product.sellingPrice * it.quantity }
    val freeThreshold = settings?.freeDeliveryThreshold ?: 500.0
    val deliveryFee = if (deliveryType == DeliveryType.HOME_DELIVERY) {
        if (subtotal >= freeThreshold) 0.0 else (settings?.deliveryCharge ?: 30.0)
    } else 0.0
    val total = subtotal + deliveryFee

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = WarmPeachSurface
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Shopping Cart & Checkout",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = WarmSlateDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = WarmSlateMuted)
                    }
                }
            }

            if (cart.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🛒", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Your cart is currently empty", fontWeight = FontWeight.Bold, color = WarmSlateDark)
                            Text("Add fresh items from the store to proceed", color = WarmSlateMuted, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                // Cart items list
                items(cart.values.toList()) { item ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = WarmPeachSurfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(getCategoryVisualIcon(item.product.name), fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.product.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = WarmSlateDark
                                )
                                Text(
                                    text = "${formatCurrency(item.product.sellingPrice, currency)} / ${item.product.unit}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmSlateMuted
                                )
                            }

                            QuantityStepper(
                                quantity = item.quantity,
                                unit = item.product.unit,
                                onDecrease = { viewModel.updateCustomerCartQuantity(item.product.id, item.quantity - 1.0) },
                                onIncrease = { viewModel.updateCustomerCartQuantity(item.product.id, item.quantity + 1.0) }
                            )

                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = formatCurrency(item.product.sellingPrice * item.quantity, currency),
                                fontWeight = FontWeight.ExtraBold,
                                color = FreshGreenPrimary,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                // DELIVERY METHOD PICKER (Home Delivery vs Pickup from Shop)
                item {
                    Text("Delivery Method", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = WarmSlateDark)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (deliveryType == DeliveryType.HOME_DELIVERY) FreshGreenContainer else WarmPeachSurfaceVariant
                            ),
                            border = if (deliveryType == DeliveryType.HOME_DELIVERY) BorderStroke(2.dp, FreshGreenPrimary) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { deliveryType = DeliveryType.HOME_DELIVERY }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DirectionsBike, contentDescription = null, tint = FreshGreenPrimary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Home Delivery", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = WarmSlateDark)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (deliveryFee == 0.0) "FREE" else "+${formatCurrency(deliveryFee, currency)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = FreshGreenPrimary
                                )
                            }
                        }

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (deliveryType == DeliveryType.PICKUP) FreshGreenContainer else WarmPeachSurfaceVariant
                            ),
                            border = if (deliveryType == DeliveryType.PICKUP) BorderStroke(2.dp, FreshGreenPrimary) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { deliveryType = DeliveryType.PICKUP }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Store, contentDescription = null, tint = FreshGreenPrimary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Shop Pickup", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = WarmSlateDark)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Ready at Counter", fontSize = 12.sp, color = WarmSlateMuted)
                            }
                        }
                    }
                }

                // DELIVERY ADDRESS / SAVED ADDRESS
                item {
                    if (deliveryType == DeliveryType.HOME_DELIVERY) {
                        Text("Delivery Address", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = WarmSlateDark)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = deliveryAddress,
                            onValueChange = { deliveryAddress = it },
                            label = { Text("Complete Address (Flat / House No., Landmark)") },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = deliveryInstructions,
                            onValueChange = { deliveryInstructions = it },
                            label = { Text("Delivery Instructions (e.g., Ring bell, Leave at gate)") },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Surface(
                            color = WarmPeachContainer,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Store Pickup Address:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FreshGreenPrimaryDark)
                                Text(settings?.shopName ?: "FreshMart Super Store", fontWeight = FontWeight.Bold, color = WarmSlateDark)
                                Text(settings?.address ?: "Market Complex, Main Road", fontSize = 12.sp, color = WarmSlateMuted)
                                Text("Hours: ${settings?.openingHours ?: "8:00 AM - 10:00 PM"}", fontSize = 12.sp, color = WarmSlateMuted)
                            }
                        }
                    }
                }

                // PAYMENT METHODS
                item {
                    Text("Payment Options", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = WarmSlateDark)
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = WarmPeachSurfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { paymentMethod = PaymentMethod.CASH }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = paymentMethod == PaymentMethod.CASH,
                                    onClick = { paymentMethod = PaymentMethod.CASH },
                                    colors = RadioButtonDefaults.colors(selectedColor = FreshGreenPrimary)
                                )
                                Text(
                                    text = if (deliveryType == DeliveryType.HOME_DELIVERY) "Cash on Delivery (COD)" else "Cash at Store Counter",
                                    fontWeight = FontWeight.SemiBold,
                                    color = WarmSlateDark
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { paymentMethod = PaymentMethod.UPI }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = paymentMethod == PaymentMethod.UPI,
                                    onClick = { paymentMethod = PaymentMethod.UPI },
                                    colors = RadioButtonDefaults.colors(selectedColor = FreshGreenPrimary)
                                )
                                Text(
                                    text = "Online UPI / QR Payment",
                                    fontWeight = FontWeight.SemiBold,
                                    color = WarmSlateDark
                                )
                            }
                        }
                    }
                }

                // BILL SUMMARY
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = WarmPeachContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Item Subtotal", style = MaterialTheme.typography.bodyMedium, color = WarmSlateMuted)
                                Text(formatCurrency(subtotal, currency), fontWeight = FontWeight.SemiBold, color = WarmSlateDark)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Delivery Charge", style = MaterialTheme.typography.bodyMedium, color = WarmSlateMuted)
                                Text(
                                    text = if (deliveryFee == 0.0) "FREE" else formatCurrency(deliveryFee, currency),
                                    fontWeight = FontWeight.SemiBold,
                                    color = FreshGreenPrimary
                                )
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = WarmPeachBorder)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Amount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                                Text(formatCurrency(total, currency), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = FreshGreenPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (activeCustomer == null) {
                                Toast.makeText(context, "Please select a customer profile", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isSubmitting = true
                            viewModel.checkoutCustomerOrder(
                                deliveryType = deliveryType,
                                deliveryAddress = deliveryAddress,
                                deliveryInstructions = deliveryInstructions,
                                paymentMethod = paymentMethod,
                                onSuccess = { orderId ->
                                    isSubmitting = false
                                    Toast.makeText(context, "Order Placed Successfully!", Toast.LENGTH_LONG).show()
                                    onOrderPlaced(orderId)
                                },
                                onError = { err ->
                                    isSubmitting = false
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                            )
                        },
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("confirm_place_order_btn")
                    ) {
                        Text(
                            text = "Place Order • ${formatCurrency(total, currency)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Customer Orders View with Live Order Tracking Action
 */
@Composable
fun CustomerOrdersView(
    viewModel: ShopViewModel,
    onTrackOrder: (Order) -> Unit,
    onReorder: (List<OrderItem>) -> Unit
) {
    val activeCustomer by viewModel.activeCustomer.collectAsState()
    val allOrders by viewModel.orders.collectAsState()
    val allOrderItems by viewModel.orderItems.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    val customerOrders = allOrders.filter { it.customerId == activeCustomer?.id }

    if (customerOrders.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("📦", fontSize = 54.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text("No orders placed yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                Text("Your completed and live orders will appear here.", color = WarmSlateMuted, textAlign = TextAlign.Center)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Your Order History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = WarmSlateDark)
            }

            items(customerOrders) { order ->
                val items = allOrderItems.filter { it.orderId == order.id }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onTrackOrder(order) },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
                    border = BorderStroke(1.dp, WarmPeachBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Order #${order.orderNumber}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = WarmSlateDark
                                )
                                Text(
                                    text = formatDateTime(order.createdAt),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmSlateMuted
                                )
                            }
                            OrderStatusBadge(status = order.orderStatus)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = WarmPeachBorder)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Items preview
                        items.take(3).forEach { item ->
                            val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else "%.1f".format(item.quantity)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.productName} ($qtyStr ${item.unit})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                    color = WarmSlateText
                                )
                                Text(
                                    text = formatCurrency(item.totalPrice, currency),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = WarmSlateDark
                                )
                            }
                        }
                        if (items.size > 3) {
                            Text("+${items.size - 3} more items", fontSize = 11.sp, color = WarmSlateMuted)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = WarmPeachBorder)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Total: ${formatCurrency(order.totalAmount, currency)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FreshGreenPrimary
                                )
                                Text(
                                    text = "${order.deliveryType.displayName} • ${order.paymentMethod.displayName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmSlateMuted
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { onTrackOrder(order) },
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, FreshGreenPrimary)
                                ) {
                                    Text("Track", color = FreshGreenPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = { onReorder(items) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreenContainer),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(14.dp), tint = OnFreshGreenContainer)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reorder", color = OnFreshGreenContainer, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Order Tracking Modal Dialog with Multi-Stage Timeline
 */
@Composable
fun OrderTrackingModal(
    order: Order,
    viewModel: ShopViewModel,
    onDismiss: () -> Unit
) {
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = WarmPeachSurface,
            border = BorderStroke(1.dp, WarmPeachBorder),
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Live Order Tracking", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                        Text("Order #${order.orderNumber}", fontSize = 13.sp, color = FreshGreenPrimary, fontWeight = FontWeight.SemiBold)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Clear, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Timeline component
                OrderTimelineTracker(currentStatus = order.orderStatus)

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = WarmPeachSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Delivery Details", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = WarmSlateDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Mode: ${order.deliveryType.displayName}", fontSize = 12.sp, color = WarmSlateText)
                        if (order.deliveryType == DeliveryType.HOME_DELIVERY) {
                            Text("Address: ${order.deliveryAddress.ifBlank { "Home Address" }}", fontSize = 12.sp, color = WarmSlateMuted)
                        }
                        Text("Amount: ${formatCurrency(order.totalAmount, currency)} (${order.paymentMethod.displayName})", fontSize = 12.sp, color = FreshGreenPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Customer Profile / Account View
 */
@Composable
fun CustomerProfileView(viewModel: ShopViewModel) {
    val activeCustomer by viewModel.activeCustomer.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    val cust = activeCustomer ?: return

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = WarmPeachContainer),
                border = BorderStroke(1.dp, WarmPeachBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(FreshGreenPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = cust.name.take(2).uppercase(),
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(cust.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                        Text(cust.phone, style = MaterialTheme.typography.bodyMedium, color = WarmSlateMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        CustomerTierBadge(tier = cust.repeatTier)
                    }
                }
            }
        }

        // Stats summary
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
                    border = BorderStroke(1.dp, WarmPeachBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total Orders", style = MaterialTheme.typography.labelMedium, color = WarmSlateMuted)
                        Text(cust.totalPurchases.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
                    border = BorderStroke(1.dp, WarmPeachBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total Spent", style = MaterialTheme.typography.labelMedium, color = WarmSlateMuted)
                        Text(formatCurrency(cust.totalAmountSpent, currency), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = FreshGreenPrimary)
                    }
                }
            }
        }

        // Primary Saved Address
        item {
            Text("Delivery Address", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarmSlateDark)
            Spacer(modifier = Modifier.height(6.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
                border = BorderStroke(1.dp, WarmPeachBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Home, contentDescription = null, tint = FreshGreenPrimary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Saved Primary Address", fontWeight = FontWeight.Bold, color = WarmSlateDark)
                        Text(cust.address.ifBlank { "Flat 402, Green Heights, Main Market Road" }, style = MaterialTheme.typography.bodyMedium, color = WarmSlateMuted)
                    }
                }
            }
        }

        // Shop Contact & Store Info
        item {
            Text("Your Local Store Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarmSlateDark)
            Spacer(modifier = Modifier.height(6.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
                border = BorderStroke(1.dp, WarmPeachBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(settings?.shopName ?: "FreshMart Super Store", fontWeight = FontWeight.Bold, color = WarmSlateDark)
                    Text("Helpline: ${settings?.phone ?: "+91 98765 43210"}", color = WarmSlateMuted)
                    Text("Store Hours: ${settings?.openingHours ?: "8:00 AM - 10:00 PM"}", color = WarmSlateMuted)
                    Text("Free Delivery on orders above ${formatCurrency(settings?.freeDeliveryThreshold ?: 500.0, currency)}", color = FreshGreenPrimary, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Customer Profile Selection Modal
 */
@Composable
fun CustomerPickerModal(
    customers: List<Customer>,
    currentCustomer: Customer?,
    onSelect: (Customer) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = WarmPeachSurface,
            border = BorderStroke(1.dp, WarmPeachBorder),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Select Customer Profile",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = WarmSlateDark
                )
                Text(
                    text = "Switch between registered customers to experience personalized orders",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmSlateMuted
                )
                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(customers) { c ->
                        val isSel = c.id == currentCustomer?.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(c) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSel) FreshGreenContainer else WarmPeachSurfaceVariant
                            ),
                            border = if (isSel) BorderStroke(1.5.dp, FreshGreenPrimary) else null
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(c.name, fontWeight = FontWeight.Bold, color = WarmSlateDark)
                                    Text(c.phone, fontSize = 12.sp, color = WarmSlateMuted)
                                }
                                CustomerTierBadge(tier = c.repeatTier)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close", color = WarmSlateDark)
                }
            }
        }
    }
}
