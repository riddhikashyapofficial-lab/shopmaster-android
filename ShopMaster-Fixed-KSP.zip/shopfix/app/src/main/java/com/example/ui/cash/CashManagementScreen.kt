package com.example.ui.cash

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CashRegisterSession
import com.example.data.model.CashTransaction
import com.example.data.model.CashTransactionType
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.ui.ShopViewModel
import com.example.ui.components.StatCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.components.formatDateTime
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg

@Composable
fun CashManagementScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val currentSession by viewModel.currentSession.collectAsState()
    val allTransactions by viewModel.cashTransactions.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    var selectedTab by remember { mutableIntStateOf(0) }
    var showOpenDialog by remember { mutableStateOf(false) }
    var showCloseDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showCashInOutDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = PrimaryEmerald
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Active Drawer", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Drawer History", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedTab) {
            0 -> ActiveDrawerTab(
                session = currentSession,
                transactions = allTransactions,
                currency = currency,
                onOpenRegister = { showOpenDialog = true },
                onCloseRegister = { showCloseDialog = true },
                onAddExpense = { showAddExpenseDialog = true },
                onCashInOut = { showCashInOutDialog = true }
            )
            1 -> DrawerHistoryTab(sessions = allSessions, currency = currency)
        }
    }

    // Open Register Dialog
    if (showOpenDialog) {
        OpenRegisterDialog(
            currency = currency,
            onDismiss = { showOpenDialog = false },
            onConfirm = { floatAmt ->
                viewModel.openRegister(floatAmt)
                showOpenDialog = false
            }
        )
    }

    // Close Register Dialog
    if (showCloseDialog && currentSession != null) {
        CloseRegisterDialog(
            session = currentSession!!,
            currency = currency,
            onDismiss = { showCloseDialog = false },
            onConfirm = { physCash, notes ->
                viewModel.closeRegister(currentSession!!.id, physCash, notes)
                showCloseDialog = false
            }
        )
    }

    // Add Cash Expense Dialog
    if (showAddExpenseDialog) {
        AddExpenseDialog(
            currency = currency,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { cat, amt, desc, receipt ->
                viewModel.addExpense(cat, amt, PaymentMethod.CASH, desc, receipt)
                showAddExpenseDialog = false
            }
        )
    }

    // Manual Cash In/Out Dialog
    if (showCashInOutDialog) {
        ManualCashInOutDialog(
            currency = currency,
            onDismiss = { showCashInOutDialog = false },
            onConfirm = { type, amt, isCredit, desc ->
                viewModel.addManualCash(type, amt, isCredit, desc)
                showCashInOutDialog = false
            }
        )
    }
}

@Composable
fun ActiveDrawerTab(
    session: CashRegisterSession?,
    transactions: List<CashTransaction>,
    currency: String,
    onOpenRegister: () -> Unit,
    onCloseRegister: () -> Unit,
    onAddExpense: () -> Unit,
    onCashInOut: () -> Unit
) {
    if (session == null) {
        Box(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))
                Text("Cash Register is Closed", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Open register to accept cash sales, record COD handovers, and track drawer float.", textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onOpenRegister,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("open_register_btn")
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open Daily Cash Register", fontWeight = FontWeight.Bold)
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Status Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LockOpen, contentDescription = null, tint = PrimaryEmerald, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Active Register Session #1", fontWeight = FontWeight.Bold)
                        }
                        Text("Opened by: ${session.openedBy} • ${formatDateTime(session.openedAt)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                    }
                    StatusBadge(text = "LIVE OPEN", containerColor = StatusSuccessBg, contentColor = StatusSuccess)
                }
            }
        }

        // Live Expected Cash Highlight Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Expected Cash in Register", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = formatCurrency(session.expectedClosingCash, currency),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(10.dp))

                    // Breakdown List
                    CashFlowRow("Opening Float Drawer Balance", session.openingCash, true, currency)
                    CashFlowRow("POS Cash Counter Sales", session.totalCashSales, true, currency)
                    CashFlowRow("COD Delivery Cash Handed-in", session.totalCodCollected, true, currency)
                    CashFlowRow("Shop Pickup Cash Payments", session.totalPickupCashCollected, true, currency)
                    CashFlowRow("Manual Cash Drawer Additions", session.totalCashAdditions, true, currency)
                    CashFlowRow("Paid-out Shop Expenses", session.totalCashExpenses, false, currency)
                    CashFlowRow("Cash Withdrawals / Bank Deposits", session.totalCashWithdrawals, false, currency)
                    CashFlowRow("Cash Refunds", session.totalRefunds, false, currency)
                }
            }
        }

        // Action Buttons Row
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onAddExpense,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("add_cash_expense_btn")
                ) {
                    Icon(Icons.Default.MoneyOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pay Expense", color = MaterialTheme.colorScheme.onSecondaryContainer)
                }

                Button(
                    onClick = onCashInOut,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cash In/Out", color = MaterialTheme.colorScheme.onSecondaryContainer)
                }

                Button(
                    onClick = onCloseRegister,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1.2f).testTag("close_register_btn")
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Close Register")
                }
            }
        }

        // Live Transaction Stream
        item {
            Text("Real-time Cash Transactions (${transactions.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(transactions) { tx ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(tx.description, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("${formatDateTime(tx.timestamp)} • User: ${tx.operatorName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (tx.isCredit) "+${formatCurrency(tx.amount, currency)}" else "-${formatCurrency(tx.amount, currency)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (tx.isCredit) StatusSuccess else StatusError
                        )
                        StatusBadge(
                            text = tx.type.displayName,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CashFlowRow(label: String, amount: Double, isCredit: Boolean, currency: String) {
    if (amount > 0.0) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                text = if (isCredit) "+${formatCurrency(amount, currency)}" else "-${formatCurrency(amount, currency)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isCredit) StatusSuccess else StatusError
            )
        }
    }
}

@Composable
fun DrawerHistoryTab(sessions: List<CashRegisterSession>, currency: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(sessions) { s ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Session #${s.id}", fontWeight = FontWeight.Bold)
                            Text("Opened: ${formatDateTime(s.openedAt)} by ${s.openedBy}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (s.isClosed) {
                            StatusBadge(text = "CLOSED", containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            StatusBadge(text = "OPEN", containerColor = StatusSuccessBg, contentColor = StatusSuccess)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Expected Cash:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatCurrency(s.expectedClosingCash, currency), fontWeight = FontWeight.Bold)
                    }

                    if (s.isClosed) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Actual Counted Cash:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatCurrency(s.actualPhysicalCash ?: 0.0, currency), fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discrepancy (Variance):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val disc = s.discrepancy ?: 0.0
                            Text(
                                text = if (disc == 0.0) "Balanced (₹0.00)" else if (disc > 0) "+${formatCurrency(disc, currency)} Surplus" else "${formatCurrency(disc, currency)} Shortage",
                                fontWeight = FontWeight.Bold,
                                color = if (disc == 0.0) StatusSuccess else StatusError
                            )
                        }
                        if (s.discrepancyNotes.isNotBlank()) {

                            Text("Notes: ${s.discrepancyNotes}", fontSize = 11.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OpenRegisterDialog(
    currency: String,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var floatAmount by remember { mutableStateOf("5000") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Open Daily Cash Register", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Enter the starting opening cash float present in the drawer.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = floatAmount,
                    onValueChange = { floatAmount = it },
                    label = { Text("Opening Cash Float ($currency)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val amt = floatAmount.toDoubleOrNull() ?: 0.0
                            onConfirm(amt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Open Drawer")
                    }
                }
            }
        }
    }
}

@Composable
fun CloseRegisterDialog(
    session: CashRegisterSession,
    currency: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var physicalCashInput by remember { mutableStateOf(session.expectedClosingCash.toInt().toString()) }
    var notes by remember { mutableStateOf("") }

    val physicalCash = physicalCashInput.toDoubleOrNull() ?: session.expectedClosingCash
    val discrepancy = physicalCash - session.expectedClosingCash

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("End-of-Day Register Closing", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("System Expected Cash:", fontSize = 13.sp)
                            Text(formatCurrency(session.expectedClosingCash, currency), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = physicalCashInput,
                    onValueChange = { physicalCashInput = it },
                    label = { Text("Actual Physical Cash Counted ($currency) *") },
                    modifier = Modifier.fillMaxWidth().testTag("physical_cash_input")
                )

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = if (discrepancy == 0.0) StatusSuccessBg else StatusErrorBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Variance / Discrepancy:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(
                            text = if (discrepancy == 0.0) "Balanced (₹0.00)" else if (discrepancy > 0) "+${formatCurrency(discrepancy, currency)} (Surplus)" else "${formatCurrency(discrepancy, currency)} (Shortage)",
                            fontWeight = FontWeight.Bold,
                            color = if (discrepancy == 0.0) StatusSuccess else StatusError
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Closing Audit Notes (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onConfirm(physicalCash, notes) },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                        modifier = Modifier.weight(1.2f).testTag("confirm_close_register_btn")
                    ) {
                        Text("Close Register")
                    }
                }
            }
        }
    }
}

@Composable
fun AddExpenseDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (ExpenseCategory, Double, String, String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.PACKAGING) }
    var amountInput by remember { mutableStateOf("150") }
    var description by remember { mutableStateOf("") }
    var receiptNote by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Record Cash Expense", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Amount will be deducted from active cash drawer.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.height(110.dp)) {
                    items(ExpenseCategory.values()) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.displayName) },
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Expense Amount ($currency) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Purpose *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = receiptNote,
                    onValueChange = { receiptNote = it },
                    label = { Text("Receipt / Bill # (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && description.isNotBlank()) {
                                onSave(selectedCategory, amt, description, receiptNote)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save & Deduct")
                    }
                }
            }
        }
    }
}

@Composable
fun ManualCashInOutDialog(
    currency: String,
    onDismiss: () -> Unit,
    onConfirm: (CashTransactionType, Double, Boolean, String) -> Unit
) {
    var isAddition by remember { mutableStateOf(true) }
    var amountInput by remember { mutableStateOf("1000") }
    var description by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Cash In / Cash Out", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isAddition,
                        onClick = { isAddition = true },
                        label = { Text("Deposit / Cash In (+)") }
                    )
                    FilterChip(
                        selected = !isAddition,
                        onClick = { isAddition = false },
                        label = { Text("Withdrawal / Bank (-)") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount ($currency) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Reason / Bank Deposit Note *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && description.isNotBlank()) {
                                onConfirm(
                                    if (isAddition) CashTransactionType.ADDITION else CashTransactionType.WITHDRAWAL,
                                    amt,
                                    isAddition,
                                    description
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Confirm")
                    }
                }
            }
        }
    }
}
