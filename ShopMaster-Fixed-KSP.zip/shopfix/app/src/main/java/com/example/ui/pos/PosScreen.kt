package com.example.ui.pos

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.ui.PosCartEntry
import com.example.ui.ShopViewModel
import com.example.ui.components.CustomerTierBadge
import com.example.ui.components.QuantityStepper
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import kotlin.math.max

data class ReceiptData(
    val invoiceNumber: String,
    val customerName: String,
    val customerPhone: String,
    val cashierName: String,
    val items: List<Triple<String, Double, Double>>,
    val subtotal: Double,
    val discount: Double,
    val tax: Double,
    val total: Double,
    val paymentMethod: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.filteredProducts.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val searchQuery by viewModel.productSearchQuery.collectAsState()
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()

    val posCart by viewModel.posCart.collectAsState()
    val selectedCustomer by viewModel.posSelectedCustomer.collectAsState()
    val discount by viewModel.posOverallDiscount.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    var showCartDrawer by remember { mutableStateOf(false) }
    var receiptDataToDisplay by remember { mutableStateOf<ReceiptData?>(null) }
    var showCustomerDialog by remember { mutableStateOf(false) }
    var barcodeInput by remember { mutableStateOf("") }
    var showBarcodeDialog by remember { mutableStateOf(false) }

    val totalItemsCount = posCart.sumOf { it.quantity }
    val subtotal = posCart.sumOf { it.product.sellingPrice * it.quantity }
    val tax = if (settings?.isTaxEnabled == true) (subtotal - discount) * (settings?.taxPercentage ?: 0.0) / 100.0 else 0.0
    val totalPayable = max(0.0, subtotal - discount + tax)

    Column(modifier = modifier.fillMaxSize()) {
        // POS Header bar with Quick Search & Barcode Scan
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setProductSearch(it) },
                        placeholder = { Text("Search product name, SKU or barcode...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setProductSearch("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("pos_search_field")
                    )

                    Button(
                        onClick = { showBarcodeDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        modifier = Modifier.testTag("pos_barcode_scan_btn")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Barcode", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Barcode", color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Category chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedCatId == null,
                            onClick = { viewModel.setCategoryFilter(null) },
                            label = { Text("All (${products.size})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryEmerald,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCatId == cat.id,
                            onClick = { viewModel.setCategoryFilter(if (selectedCatId == cat.id) null else cat.id) },
                            label = { Text(cat.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryEmerald,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Product Grid / List for POS selection
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(products) { prod ->
                val inCart = posCart.find { it.product.id == prod.id }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.addToPosCart(prod, 1.0) }
                        .testTag("pos_item_${prod.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (inCart != null) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = prod.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "SKU: ${prod.sku.ifBlank { "N/A" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (prod.currentStock <= 0.0) {
                                    StatusBadge(text = "Out of Stock", containerColor = StatusErrorBg, contentColor = StatusError)
                                } else if (prod.currentStock <= prod.minStockLevel) {
                                    StatusBadge(text = "Stock: ${prod.currentStock.toInt()}", containerColor = StatusWarningBg, contentColor = StatusWarning)
                                } else {
                                    StatusBadge(text = "Stock: ${prod.currentStock.toInt()}", containerColor = StatusSuccessBg, contentColor = StatusSuccess)
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = formatCurrency(prod.sellingPrice, currency),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryEmerald
                            )

                            if (inCart != null) {
                                val qtyStr = if (inCart.quantity % 1.0 == 0.0) inCart.quantity.toInt().toString() else "%.1f".format(inCart.quantity)
                                Text(
                                    text = "$qtyStr in Bill",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryEmerald
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom POS Billing Bar (Always visible)
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    val countStr = if (totalItemsCount % 1.0 == 0.0) totalItemsCount.toInt().toString() else "%.1f".format(totalItemsCount)
                    Text(
                        text = "Current Bill ($countStr items)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(totalPayable, currency),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (posCart.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { viewModel.clearPosCart() },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Clear")
                        }
                    }

                    Button(
                        onClick = { showCartDrawer = true },
                        enabled = posCart.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("pos_checkout_drawer_btn")
                    ) {
                        Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Checkout (${formatCurrency(totalPayable, currency)})", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // POS Checkout / Payment Drawer
    if (showCartDrawer) {
        PosPaymentDrawer(
            viewModel = viewModel,
            posCart = posCart,
            selectedCustomer = selectedCustomer,
            subtotal = subtotal,
            discount = discount,
            tax = tax,
            totalPayable = totalPayable,
            currency = currency,
            onDismiss = { showCartDrawer = false },
            onCompleteSale = { paymentMethod, notes ->
                viewModel.completePosSale(
                    paymentMethod = paymentMethod,
                    notes = notes,
                    onSuccess = { saleId ->
                        showCartDrawer = false
                        // Prepare printed receipt data
                        val invoiceNum = "INV-${System.currentTimeMillis() % 1000000}"
                        receiptDataToDisplay = ReceiptData(
                            invoiceNumber = invoiceNum,
                            customerName = selectedCustomer?.name ?: "Walk-in Customer",
                            customerPhone = selectedCustomer?.phone ?: "",
                            cashierName = viewModel.currentOperatorName.value,
                            items = posCart.map { Triple(it.product.name, it.quantity, it.product.sellingPrice * it.quantity) },
                            subtotal = subtotal,
                            discount = discount,
                            tax = tax,
                            total = totalPayable,
                            paymentMethod = paymentMethod.displayName
                        )
                        Toast.makeText(context, "Sale Completed & Bill Generated!", Toast.LENGTH_SHORT).show()
                    },
                    onError = { err ->
                        Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                    }
                )
            },
            onSelectCustomer = { showCustomerDialog = true }
        )
    }

    // Customer Selector Dialog for POS
    if (showCustomerDialog) {
        PosCustomerSelectDialog(
            viewModel = viewModel,
            onDismiss = { showCustomerDialog = false },
            onSelect = { cust ->
                viewModel.setPosCustomer(cust)
                showCustomerDialog = false
            }
        )
    }

    // Barcode Simulation Dialog
    if (showBarcodeDialog) {
        BarcodeScannerDialog(
            onDismiss = { showBarcodeDialog = false },
            onBarcodeScanned = { scannedCode ->
                val match = viewModel.products.value.find { it.barcode.equals(scannedCode, ignoreCase = true) || it.sku.equals(scannedCode, ignoreCase = true) }
                if (match != null) {
                    viewModel.addToPosCart(match, 1.0)
                    Toast.makeText(context, "Added: ${match.name}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "No product found with barcode $scannedCode", Toast.LENGTH_SHORT).show()
                }
                showBarcodeDialog = false
            }
        )
    }

    // Thermal Receipt Dialog Preview
    receiptDataToDisplay?.let { r ->
        ReceiptDialog(
            invoiceNumber = r.invoiceNumber,
            customerName = r.customerName,
            customerPhone = r.customerPhone,
            cashierName = r.cashierName,
            items = r.items,
            subtotal = r.subtotal,
            discount = r.discount,
            tax = r.tax,
            total = r.total,
            paymentMethod = r.paymentMethod,
            shopSettings = settings,
            onDismiss = { receiptDataToDisplay = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosPaymentDrawer(
    viewModel: ShopViewModel,
    posCart: List<PosCartEntry>,
    selectedCustomer: Customer?,
    subtotal: Double,
    discount: Double,
    tax: Double,
    totalPayable: Double,
    currency: String,
    onDismiss: () -> Unit,
    onCompleteSale: (PaymentMethod, String) -> Unit,
    onSelectCustomer: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var cashTenderedInput by remember { mutableStateOf(totalPayable.toInt().toString()) }
    var discountInput by remember { mutableStateOf(discount.toString()) }
    var saleNotes by remember { mutableStateOf("") }

    val cashTendered = cashTenderedInput.toDoubleOrNull() ?: totalPayable
    val changeDue = max(0.0, cashTendered - totalPayable)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(bottom = 30.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("POS Billing & Checkout", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Clear, contentDescription = "Close") }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Customer Selector Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectCustomer() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryEmerald)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = selectedCustomer?.name ?: "Walk-in Customer (Default)",
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (selectedCustomer != null) selectedCustomer.phone else "Tap to link customer & repeat points",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (selectedCustomer != null) {
                            CustomerTierBadge(tier = selectedCustomer.repeatTier)
                        } else {
                            Text("Change", color = PrimaryEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Line items in bill
            items(posCart) { entry ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(entry.product.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = "${formatCurrency(entry.product.sellingPrice, currency)} / ${entry.product.unit}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    QuantityStepper(
                        quantity = entry.quantity,
                        unit = entry.product.unit,
                        onDecrease = { viewModel.updatePosCartQuantity(entry.product.id, entry.quantity - 1.0) },
                        onIncrease = { viewModel.updatePosCartQuantity(entry.product.id, entry.quantity + 1.0) }
                    )

                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = formatCurrency(entry.product.sellingPrice * entry.quantity, currency),
                        fontWeight = FontWeight.Bold
                    )

                    IconButton(
                        onClick = { viewModel.removePosCartItem(entry.product.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Remove", tint = StatusError, modifier = Modifier.size(18.dp))
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            }

            // Discount & Payment Method
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = discountInput,
                        onValueChange = {
                            discountInput = it
                            viewModel.setPosOverallDiscount(it.toDoubleOrNull() ?: 0.0)
                        },
                        label = { Text("Bill Discount ($currency)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = saleNotes,
                        onValueChange = { saleNotes = it },
                        label = { Text("Sale Notes") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text("Select Payment Method", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPaymentMethod = PaymentMethod.CASH },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPaymentMethod == PaymentMethod.CASH) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("💵 Cash", fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPaymentMethod = PaymentMethod.UPI },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPaymentMethod == PaymentMethod.UPI) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("📱 UPI QR", fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPaymentMethod = PaymentMethod.CARD },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPaymentMethod == PaymentMethod.CARD) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("💳 Card", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Cash Tender Calculator
            item {
                if (selectedPaymentMethod == PaymentMethod.CASH) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = cashTenderedInput,
                                    onValueChange = { cashTenderedInput = it },
                                    label = { Text("Cash Given by Customer ($currency)") },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Change Due:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = formatCurrency(changeDue, currency),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (changeDue > 0) StatusSuccess else PrimaryEmerald
                                    )
                                }
                            }

                            // Quick Tender Buttons
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val exactVal = totalPayable.toInt()
                                val denominations = listOf(exactVal, 500, 1000, 2000).distinct()
                                denominations.forEach { amt ->
                                    OutlinedButton(
                                        onClick = { cashTenderedInput = amt.toString() },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("₹$amt", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Final Bill Summary & Complete Action
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                            Text(formatCurrency(subtotal, currency), fontWeight = FontWeight.SemiBold)
                        }
                        if (discount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount", style = MaterialTheme.typography.bodyMedium, color = StatusSuccess)
                                Text("-${formatCurrency(discount, currency)}", color = StatusSuccess, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (tax > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("GST / Tax", style = MaterialTheme.typography.bodyMedium)
                                Text(formatCurrency(tax, currency), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("NET TOTAL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(formatCurrency(totalPayable, currency), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { onCompleteSale(selectedPaymentMethod, saleNotes) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pos_complete_sale_btn")
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Sale & Print Bill (${formatCurrency(totalPayable, currency)})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun PosCustomerSelectDialog(
    viewModel: ShopViewModel,
    onDismiss: () -> Unit,
    onSelect: (Customer?) -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    var searchCust by remember { mutableStateOf("") }
    var showNewCustomerForm by remember { mutableStateOf(false) }

    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newAddress by remember { mutableStateOf("") }

    val filtered = customers.filter {
        it.name.contains(searchCust, ignoreCase = true) || it.phone.contains(searchCust)
    }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Select POS Customer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                if (!showNewCustomerForm) {
                    OutlinedTextField(
                        value = searchCust,
                        onValueChange = { searchCust = it },
                        placeholder = { Text("Search by name or mobile number...") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    // Walk-in option
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(null) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("👤 Walk-in Customer (No details)", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.height(200.dp)) {
                        items(filtered) { c ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clickable { onSelect(c) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(c.name, fontWeight = FontWeight.Bold)
                                        Text(c.phone, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    CustomerTierBadge(tier = c.repeatTier)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showNewCustomerForm = true }, modifier = Modifier.weight(1f)) {
                            Text("+ New Customer")
                        }
                        Button(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                    }
                } else {
                    // Quick add customer form
                    Text("Add New Customer", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(value = newPhone, onValueChange = { newPhone = it }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(value = newAddress, onValueChange = { newAddress = it }, label = { Text("Address (Optional)") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showNewCustomerForm = false }, modifier = Modifier.weight(1f)) {
                            Text("Back")
                        }
                        Button(
                            onClick = {
                                if (newName.isNotBlank() && newPhone.isNotBlank()) {
                                    val newC = Customer(
                                        name = newName,
                                        phone = newPhone,
                                        address = newAddress
                                    )
                                    viewModel.saveCustomer(newC) { newId ->
                                        onSelect(newC.copy(id = newId))
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save & Select")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeScannerDialog(
    onDismiss: () -> Unit,
    onBarcodeScanned: (String) -> Unit
) {
    var barcodeText by remember { mutableStateOf("8901234001") }
    val presetBarcodes = listOf(
        Pair("Fortune Oil", "8901234001"),
        Pair("Aashirvaad Atta", "8901234002"),
        Pair("India Gate Rice", "8901234003"),
        Pair("Tata Salt", "8901234004"),
        Pair("Amul Butter", "8901234005"),
        Pair("Dettol Soap", "8901234015")
    )

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = PrimaryEmerald)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Barcode Scanner Simulation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = barcodeText,
                    onValueChange = { barcodeText = it },
                    label = { Text("Barcode / SKU") },
                    modifier = Modifier.fillMaxWidth().testTag("barcode_input_field")
                )

                Spacer(modifier = Modifier.height(10.dp))
                Text("Tap quick sample item barcode:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(presetBarcodes) { (name, code) ->
                        FilterChip(
                            selected = barcodeText == code,
                            onClick = { barcodeText = code },
                            label = { Text(name, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onBarcodeScanned(barcodeText) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f).testTag("simulate_scan_btn")
                    ) {
                        Text("Scan & Add")
                    }
                }
            }
        }
    }
}
