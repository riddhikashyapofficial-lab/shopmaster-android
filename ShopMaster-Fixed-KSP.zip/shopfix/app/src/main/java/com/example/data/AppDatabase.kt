package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AuditLogDao
import com.example.data.dao.CashDao
import com.example.data.dao.CustomerDao
import com.example.data.dao.EmployeeDao
import com.example.data.dao.ExpenseDao
import com.example.data.dao.NotificationDao
import com.example.data.dao.OfflineSaleDao
import com.example.data.dao.OrderDao
import com.example.data.dao.ProductDao
import com.example.data.dao.PurchaseDao
import com.example.data.dao.ShopSettingsDao
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.CashRegisterSession
import com.example.data.model.CashTransaction
import com.example.data.model.CashTransactionType
import com.example.data.model.Category
import com.example.data.model.Customer
import com.example.data.model.CustomerAddress
import com.example.data.model.CustomerRepeatTier
import com.example.data.model.DeliveryType
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.InventoryMovement
import com.example.data.model.MovementType
import com.example.data.model.NotificationType
import com.example.data.model.OfflineSale
import com.example.data.model.OfflineSaleItem
import com.example.data.model.Order
import com.example.data.model.OrderItem
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.ProductImage
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseOrderItem
import com.example.data.model.ShopSettings
import com.example.data.model.Supplier
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Category::class,
        Product::class,
        ProductImage::class,
        InventoryMovement::class,
        Customer::class,
        CustomerAddress::class,
        Order::class,
        OrderItem::class,
        OfflineSale::class,
        OfflineSaleItem::class,
        CashRegisterSession::class,
        CashTransaction::class,
        Expense::class,
        Supplier::class,
        PurchaseOrder::class,
        PurchaseOrderItem::class,
        AuditLog::class,
        AppNotification::class,
        ShopSettings::class,
        Employee::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun orderDao(): OrderDao
    abstract fun offlineSaleDao(): OfflineSaleDao
    abstract fun cashDao(): CashDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun notificationDao(): NotificationDao
    abstract fun shopSettingsDao(): ShopSettingsDao
    abstract fun employeeDao(): EmployeeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shopmaster_database"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateInitialData(database)
                }
            }
        }
    }
}

suspend fun populateInitialData(db: AppDatabase) {
    // 1. Initial Settings
    db.shopSettingsDao().insertSettings(
        ShopSettings(
            id = 1,
            shopName = "FreshMart Super Store",
            address = "Shop No. 4, Market Complex, MG Road",
            phone = "+91 98765 43210",
            email = "owner@freshmart.store",
            openingHours = "8:00 AM - 10:00 PM",
            deliveryCharge = 25.0,
            minOrderValue = 100.0,
            freeDeliveryThreshold = 500.0,
            currencySymbol = "₹"
        )
    )

    // 2. Initial Employees
    val employees = listOf(
        Employee(1, "Vikram Sharma (Owner)", "+91 98765 43210", "vikram@freshmart.store", UserRole.OWNER),
        Employee(2, "Ananya Rao", "+91 98111 22334", "ananya@freshmart.store", UserRole.MANAGER),
        Employee(3, "Rohan Verma", "+91 98222 33445", "rohan@freshmart.store", UserRole.CASHIER),
        Employee(4, "Deepak Yadav", "+91 98333 44556", "deepak@freshmart.store", UserRole.STOCK_STAFF),
        Employee(5, "Sunil Kumar", "+91 98444 55667", "sunil@freshmart.store", UserRole.DELIVERY_STAFF)
    )
    db.employeeDao().insertAllEmployees(employees)

    // 3. Categories
    val categories = listOf(
        Category(1, "Daily Staples & Rice", "rice", 1),
        Category(2, "Dairy, Bread & Eggs", "egg", 2),
        Category(3, "Fresh Fruits & Veggies", "leaf", 3),
        Category(4, "Snacks & Beverages", "coffee", 4),
        Category(5, "Personal & Home Care", "clean", 5)
    )
    db.productDao().insertAllCategories(categories)

    // 4. Products with realistic barcodes & costs
    val products = listOf(
        Product(1, "Fortune Sunlite Refined Oil 1L", 1, "Pouch pack pure refined sunflower cooking oil", 145.0, 120.0, 48.0, 10.0, "ltr", "OIL-001", "8901234001"),
        Product(2, "Aashirvaad Shudh Chakki Atta 5kg", 1, "100% whole wheat whole meal flour rich in fiber", 260.0, 220.0, 32.0, 8.0, "pack", "ATTA-005", "8901234002"),
        Product(3, "India Gate Basmati Rice Feast 1kg", 1, "Aromatic long grain basmati rice for daily meals", 115.0, 92.0, 60.0, 12.0, "kg", "RICE-001", "8901234003"),
        Product(4, "Tata Salt Vacuum Evaporated 1kg", 1, "Iodized salt for healthy thyroid functioning", 28.0, 22.0, 95.0, 15.0, "pack", "SALT-001", "8901234004"),
        Product(5, "Amul Butter Pasteurized 500g", 2, "Delicious salted creamy pure butter", 285.0, 255.0, 24.0, 6.0, "pack", "AMUL-500", "8901234005"),
        Product(6, "Amul Taaza Homogenised Milk 1L", 2, "Fresh toned milk, rich in calcium and protein", 72.0, 62.0, 40.0, 10.0, "ltr", "MILK-001", "8901234006"),
        Product(7, "Farm Fresh White Eggs 6 pcs", 2, "Protein rich sanitized farm fresh eggs tray", 54.0, 42.0, 30.0, 8.0, "tray", "EGG-006", "8901234007"),
        Product(8, "Modern Sandwich Bread 400g", 2, "Soft sliced white sandwich bread", 45.0, 36.0, 18.0, 5.0, "pack", "BREAD-400", "8901234008"),
        Product(9, "Fresh Farm Potatoes (Aloo) 1kg", 3, "Handpicked premium medium-sized potatoes", 32.0, 22.0, 85.0, 15.0, "kg", "VEG-POT", "8901234009"),
        Product(10, "Fresh Red Onions (Pyaz) 1kg", 3, "Crisp aromatic red farm onions", 38.0, 28.0, 70.0, 15.0, "kg", "VEG-ONI", "8901234010"),
        Product(11, "Fresh Ripe Bananas 1 Dozen", 3, "Sweet golden robust Cavendish bananas", 60.0, 42.0, 22.0, 6.0, "doz", "FRU-BAN", "8901234011"),
        Product(12, "Lay's India's Magic Masala 50g", 4, "Crunchy spiced potato chips", 20.0, 16.0, 75.0, 15.0, "pack", "SNK-LAY", "8901234012"),
        Product(13, "Maggi 2-Minute Instant Noodles 280g", 4, "4-pack delicious masala instant noodles", 60.0, 48.0, 45.0, 10.0, "pack", "SNK-MAG", "8901234013"),
        Product(14, "Coca-Cola Original Taste 750ml", 4, "Chilled refreshing sparkling soda bottle", 40.0, 32.0, 50.0, 10.0, "btl", "BEV-COK", "8901234014"),
        Product(15, "Dettol Original Bathing Soap 125g (Buy 3 Get 1)", 5, "Trusted germ protection anti-bacterial soap", 165.0, 135.0, 28.0, 6.0, "pack", "PC-DETT", "8901234015"),
        Product(16, "Surf Excel Easy Wash Detergent Powder 1kg", 5, "Superior stain removal washing powder", 145.0, 118.0, 35.0, 8.0, "kg", "HC-SURF", "8901234016"),
        Product(17, "Colgate Strong Teeth Toothpaste 200g", 5, "Cavity protection calcium & fluoride toothpaste", 110.0, 88.0, 3.0, 10.0, "pack", "PC-COLG", "8901234017") // Low stock example
    )
    db.productDao().insertAllProducts(products)

    // 5. Initial Customers & Repeat Classification
    val customers = listOf(
        Customer(1, "Rahul Sharma", "+91 98765 11111", "rahul@email.com", "Flat 402, Green Heights, Main Road", 12, 4, 8, 8450.0, 704.0, System.currentTimeMillis() - 86400000L * 2, System.currentTimeMillis() - 86400000L * 60, "Prefers contactless delivery", CustomerRepeatTier.REGULAR),
        Customer(2, "Pooja Patel", "+91 98765 22222", "pooja@email.com", "B-12, Shanti Niketan Society", 6, 5, 1, 4200.0, 700.0, System.currentTimeMillis() - 86400000L * 1, System.currentTimeMillis() - 86400000L * 40, "Call before ringing doorbell", CustomerRepeatTier.REGULAR),
        Customer(3, "Amitabh Roy", "+91 98765 33333", "amitabh@email.com", "Plot 88, Sector 4", 2, 0, 2, 950.0, 475.0, System.currentTimeMillis() - 86400000L * 5, System.currentTimeMillis() - 86400000L * 20, "", CustomerRepeatTier.RETURNING),
        Customer(4, "Neha Gupta", "+91 98765 44444", "neha@email.com", "House 15, Lake View Road", 1, 1, 0, 680.0, 680.0, System.currentTimeMillis() - 86400000L * 1, System.currentTimeMillis() - 86400000L * 1, "", CustomerRepeatTier.NEW),
        Customer(5, "Ramesh Chandra", "+91 98765 55555", "", "Market Lane Corner", 4, 0, 4, 1800.0, 450.0, System.currentTimeMillis() - 86400000L * 45, System.currentTimeMillis() - 86400000L * 120, "Needs re-engagement offer", CustomerRepeatTier.INACTIVE)
    )
    db.customerDao().insertAllCustomers(customers)

    val addresses = listOf(
        CustomerAddress(1, 1, "Home", "Flat 402, Green Heights, Main Road", "Near City Mall", "Local Area", "400001", "+91 98765 11111", true),
        CustomerAddress(2, 2, "Home", "B-12, Shanti Niketan Society", "Opposite Park", "Local Area", "400001", "+91 98765 22222", true)
    )
    db.customerDao().insertAllAddresses(addresses)

    // 6. Cash Register Opening
    val currentSession = CashRegisterSession(
        id = 1,
        openedAt = System.currentTimeMillis() - 3600000L * 4,
        openedBy = "Vikram Sharma (Owner)",
        openingCash = 5000.0,
        totalCashSales = 1840.0,
        totalCodCollected = 680.0,
        totalPickupCashCollected = 260.0,
        totalCashExpenses = 150.0,
        totalCashWithdrawals = 0.0,
        totalCashAdditions = 0.0,
        totalRefunds = 0.0,
        expectedClosingCash = 7630.0,
        isClosed = false
    )
    db.cashDao().insertSession(currentSession)

    db.cashDao().insertAllCashTransactions(
        listOf(
            CashTransaction(1, 1, CashTransactionType.OPENING_BALANCE, 5000.0, true, "Morning Register Opening Drawer", "", "Vikram Sharma", System.currentTimeMillis() - 3600000L * 4),
            CashTransaction(2, 1, CashTransactionType.CASH_SALE_POS, 840.0, true, "POS Bill #INV-1001", "INV-1001", "Rohan Verma", System.currentTimeMillis() - 3600000L * 3),
            CashTransaction(3, 1, CashTransactionType.CASH_SALE_POS, 1000.0, true, "POS Bill #INV-1002", "INV-1002", "Rohan Verma", System.currentTimeMillis() - 3600000L * 2),
            CashTransaction(4, 1, CashTransactionType.EXPENSE_PAID, 150.0, false, "Packing polythene and brown paper bags", "EXP-01", "Vikram Sharma", System.currentTimeMillis() - 3600000L * 1),
            CashTransaction(5, 1, CashTransactionType.COD_DELIVERY, 680.0, true, "COD Cash collected for Order #ORD-501", "ORD-501", "Sunil Kumar", System.currentTimeMillis() - 1800000L),
            CashTransaction(6, 1, CashTransactionType.PICKUP_PAYMENT, 260.0, true, "Counter Pickup Cash for Order #ORD-502", "ORD-502", "Rohan Verma", System.currentTimeMillis() - 900000L)
        )
    )

    // 7. Suppliers
    val suppliers = listOf(
        Supplier(1, "Metro Wholesale Distributors", "Suresh Gupta", "+91 98990 01122", "metro@distrib.in", "Wholesale Hub, Sector 18", "27AAAAA0000A1Z5"),
        Supplier(2, "Amul Dairy Cooperative Agency", "Manish Shah", "+91 98990 03344", "amul@distrib.in", "Dairy Road, Unit 3", "27BBBBB1111B1Z2")
    )
    db.purchaseDao().insertAllSuppliers(suppliers)

    // 8. Past Orders & Items
    val orders = listOf(
        Order(1, "ORD-501", 1, "Rahul Sharma", "+91 98765 11111", DeliveryType.HOME_DELIVERY, "Flat 402, Green Heights, Main Road", "Ring bell twice", 655.0, 25.0, 0.0, 680.0, PaymentMethod.CASH, PaymentStatus.PAID, OrderStatus.DELIVERED, 5, "Sunil Kumar", "", System.currentTimeMillis() - 3600000L * 3, System.currentTimeMillis() - 1800000L),
        Order(2, "ORD-502", 2, "Pooja Patel", "+91 98765 22222", DeliveryType.PICKUP, "Pickup From Shop Counter", "Will pick up around 4pm", 260.0, 0.0, 0.0, 260.0, PaymentMethod.CASH_AT_PICKUP, PaymentStatus.PAID, OrderStatus.COMPLETED, null, "", "", System.currentTimeMillis() - 3600000L * 2, System.currentTimeMillis() - 900000L),
        Order(3, "ORD-503", 4, "Neha Gupta", "+91 98765 44444", DeliveryType.HOME_DELIVERY, "House 15, Lake View Road", "Leave at door", 495.0, 25.0, 0.0, 520.0, PaymentMethod.UPI, PaymentStatus.PAID, OrderStatus.PREPARING, 5, "Sunil Kumar", "", System.currentTimeMillis() - 1800000L, System.currentTimeMillis() - 600000L),
        Order(4, "ORD-504", 3, "Amitabh Roy", "+91 98765 33333", DeliveryType.HOME_DELIVERY, "Plot 88, Sector 4", "Call on arrival", 380.0, 25.0, 0.0, 405.0, PaymentMethod.CASH, PaymentStatus.PENDING, OrderStatus.ORDER_RECEIVED, null, "", "", System.currentTimeMillis() - 600000L, System.currentTimeMillis() - 600000L)
    )
    db.orderDao().insertAllOrders(orders)

    db.orderDao().insertOrderItems(
        listOf(
            OrderItem(1, 1, 2, "Aashirvaad Shudh Chakki Atta 5kg", 260.0, 220.0, "pack", 1.0, 260.0),
            OrderItem(2, 1, 1, "Fortune Sunlite Refined Oil 1L", 145.0, 120.0, "ltr", 2.0, 290.0),
            OrderItem(3, 1, 5, "Amul Butter Pasteurized 500g", 285.0, 255.0, "pack", 0.37, 105.0),
            OrderItem(4, 2, 2, "Aashirvaad Shudh Chakki Atta 5kg", 260.0, 220.0, "pack", 1.0, 260.0),
            OrderItem(5, 3, 15, "Dettol Original Bathing Soap 125g", 165.0, 135.0, "pack", 1.0, 165.0),
            OrderItem(6, 3, 16, "Surf Excel Easy Wash Detergent Powder 1kg", 145.0, 118.0, "kg", 1.0, 145.0),
            OrderItem(7, 3, 6, "Amul Taaza Homogenised Milk 1L", 72.0, 62.0, "ltr", 2.0, 144.0),
            OrderItem(8, 3, 8, "Modern Sandwich Bread 400g", 45.0, 36.0, "pack", 1.0, 41.0),
            OrderItem(9, 4, 3, "India Gate Basmati Rice Feast 1kg", 115.0, 92.0, "kg", 2.0, 230.0),
            OrderItem(10, 4, 1, "Fortune Sunlite Refined Oil 1L", 145.0, 120.0, "ltr", 1.0, 145.0)
        )
    )

    // 9. Offline Sales & Items
    val offlineSales = listOf(
        OfflineSale(1, "INV-1001", 1, "Rahul Sharma", "+91 98765 11111", "Rohan Verma", 840.0, 0.0, 0.0, 840.0, PaymentMethod.CASH, PaymentStatus.PAID, false, "Walk-in repeat customer", System.currentTimeMillis() - 3600000L * 3),
        OfflineSale(2, "INV-1002", 0, "Walk-in Customer", "", "Rohan Verma", 1000.0, 0.0, 0.0, 1000.0, PaymentMethod.CASH, PaymentStatus.PAID, false, "Cash counter purchase", System.currentTimeMillis() - 3600000L * 2),
        OfflineSale(3, "INV-1003", 3, "Amitabh Roy", "+91 98765 33333", "Rohan Verma", 475.0, 0.0, 0.0, 475.0, PaymentMethod.UPI, PaymentStatus.PAID, false, "UPI Scan & Pay", System.currentTimeMillis() - 3600000L * 1)
    )
    db.offlineSaleDao().insertAllSales(offlineSales)

    db.offlineSaleDao().insertSaleItems(
        listOf(
            OfflineSaleItem(1, 1, 5, "Amul Butter Pasteurized 500g", 285.0, 255.0, "pack", 2.0, 570.0),
            OfflineSaleItem(2, 1, 6, "Amul Taaza Homogenised Milk 1L", 72.0, 62.0, "ltr", 3.0, 216.0),
            OfflineSaleItem(3, 1, 7, "Farm Fresh White Eggs 6 pcs", 54.0, 42.0, "tray", 1.0, 54.0),
            OfflineSaleItem(4, 2, 2, "Aashirvaad Shudh Chakki Atta 5kg", 260.0, 220.0, "pack", 2.0, 520.0),
            OfflineSaleItem(5, 2, 3, "India Gate Basmati Rice Feast 1kg", 115.0, 92.0, "kg", 4.0, 460.0),
            OfflineSaleItem(6, 2, 4, "Tata Salt Vacuum Evaporated 1kg", 28.0, 22.0, "pack", 1.0, 20.0),
            OfflineSaleItem(7, 3, 15, "Dettol Original Bathing Soap 125g", 165.0, 135.0, "pack", 2.0, 330.0),
            OfflineSaleItem(8, 3, 13, "Maggi 2-Minute Instant Noodles 280g", 60.0, 48.0, "pack", 2.0, 120.0),
            OfflineSaleItem(9, 3, 14, "Coca-Cola Original Taste 750ml", 40.0, 32.0, "btl", 1.0, 25.0)
        )
    )

    // 10. Expenses
    db.expenseDao().insertAllExpenses(
        listOf(
            Expense(1, ExpenseCategory.PACKAGING, 150.0, System.currentTimeMillis() - 3600000L * 1, PaymentMethod.CASH, "Packaging bags bundle", "Vikram Sharma", "Receipt #PK-99"),
            Expense(2, ExpenseCategory.ELECTRICITY, 3400.0, System.currentTimeMillis() - 86400000L * 5, PaymentMethod.UPI, "Monthly shop electricity bill for freezers & lighting", "Vikram Sharma", "Bill #EB-4402")
        )
    )

    // 11. Inventory Movement Log
    val movements = listOf(
        InventoryMovement(1, 1, "Fortune Sunlite Refined Oil 1L", 50.0, MovementType.STOCK_RECEIVED, 0.0, 50.0, "Deepak Yadav", "Initial Stock Inward from Metro Distributors", "PO-101", System.currentTimeMillis() - 86400000L * 2),
        InventoryMovement(2, 2, "Aashirvaad Shudh Chakki Atta 5kg", 35.0, MovementType.STOCK_RECEIVED, 0.0, 35.0, "Deepak Yadav", "Inward stock receiving", "PO-101", System.currentTimeMillis() - 86400000L * 2),
        InventoryMovement(3, 1, "Fortune Sunlite Refined Oil 1L", -2.0, MovementType.ONLINE_SALE, 50.0, 48.0, "System", "Online Order #ORD-501", "ORD-501", System.currentTimeMillis() - 3600000L * 3),
        InventoryMovement(4, 5, "Amul Butter Pasteurized 500g", -2.0, MovementType.OFFLINE_SALE, 26.0, 24.0, "Rohan Verma", "POS Sale Bill #INV-1001", "INV-1001", System.currentTimeMillis() - 3600000L * 3),
        InventoryMovement(5, 17, "Colgate Strong Teeth Toothpaste 200g", -2.0, MovementType.DAMAGED, 5.0, 3.0, "Deepak Yadav", "Outer box crushed in transit", "DMG-01", System.currentTimeMillis() - 3600000L * 1)
    )
    for (m in movements) {
        db.productDao().insertMovement(m)
    }

    // 12. Audit Logs
    db.auditLogDao().insertAllAuditLogs(
        listOf(
            AuditLog(1, "Vikram Sharma", UserRole.OWNER, "OPEN_REGISTER", "CASH_DRAWER", "SESSION-1", "Opened daily cash register with ₹5,000 opening float", "", "₹5,000.00", System.currentTimeMillis() - 3600000L * 4),
            AuditLog(2, "Deepak Yadav", UserRole.STOCK_STAFF, "STOCK_ADJUSTMENT", "PRODUCT", "17", "Marked 2 pcs of Colgate Toothpaste as damaged", "5.0 pcs", "3.0 pcs", System.currentTimeMillis() - 3600000L * 1)
        )
    )

    // 13. Notifications
    db.notificationDao().insertAllNotifications(
        listOf(
            AppNotification(1, "Low Stock Warning", "Colgate Strong Teeth Toothpaste is low in stock (3 pcs left). Please reorder from supplier.", NotificationType.STOCK_ALERT, false, System.currentTimeMillis() - 3600000L * 1),
            AppNotification(2, "New Online Order #ORD-504", "New order received from Amitabh Roy for ₹405 (Cash on Delivery).", NotificationType.ORDER, false, System.currentTimeMillis() - 600000L)
        )
    )
}
