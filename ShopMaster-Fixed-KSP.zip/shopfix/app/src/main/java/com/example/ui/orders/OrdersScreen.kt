package com.example.ui.orders

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryType
import com.example.data.model.Employee
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentStatus
import com.example.data.model.UserRole
import com.example.ui.ShopViewModel
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.components.formatDateTime
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg

@Composable
fun OrdersManagementScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsState()
    val orderItems by viewModel.orderItems.collectAsState()
    val employees by viewModel.employees.collectAsState()
    val statusFilter by viewModel.orderStatusFilter.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    var orderToAssignDelivery by remember { mutableStateOf<Order?>(null) }
    var orderToCancel by remember { mutableStateOf<Order?>(null) }

    val filteredOrders = orders.filter { o ->
        statusFilter == null || o.orderStatus == statusFilter
    }

    val deliveryStaffList = employees.filter { it.role == UserRole.DELIVERY_STAFF || it.role == UserRole.MANAGER || it.role == UserRole.OWNER }

    Column(modifier = modifier.fillMaxSize()) {
        // Status Filter Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterChip(
                    selected = statusFilter == null,
                    onClick = { viewModel.setOrderStatusFilter(null) },
                    label = { Text("All (${orders.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryEmerald,
                        selectedLabelColor = Color.White
                    )
                )
            }
            items(OrderStatus.values()) { st ->
                val count = orders.count { it.orderStatus == st }
                FilterChip(
                    selected = statusFilter == st,
                    onClick = { viewModel.setOrderStatusFilter(if (statusFilter == st) null else st) },
                    label = { Text("${st.displayName} ($count)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryEmerald,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Orders List
        if (filteredOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No orders found for selected status filter.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredOrders) { order ->
                    val items = orderItems.filter { it.orderId == order.id }
                    OrderManagementCard(
                        order = order,
                        items = items,
                        currency = currency,
                        onUpdateStatus = { newSt -> viewModel.updateOrderStatus(order.id, newSt) },
                        onAssignDelivery = { orderToAssignDelivery = order },
                        onCancelOrder = { orderToCancel = order }
                    )
                }
            }
        }
    }

    // Assign Delivery Dialog
    orderToAssignDelivery?.let { ord ->
        AssignDeliveryStaffDialog(
            order = ord,
            staffList = deliveryStaffList,
            onDismiss = { orderToAssignDelivery = null },
            onAssign = { staffId, staffName ->
                viewModel.assignDelivery(ord.id, staffId, staffName)
                orderToAssignDelivery = null
            }
        )
    }

    // Cancel / Refund Dialog
    orderToCancel?.let { ord ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { orderToCancel = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Cancel Order #${ord.orderNumber}?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = StatusError)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Cancelling this order will automatically restore all reserved stock back to the Master Inventory and record an audit log.", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { orderToCancel = null }, modifier = Modifier.weight(1f)) {
                            Text("No, Keep")
                        }
                        Button(
                            onClick = {
                                viewModel.updateOrderStatus(ord.id, OrderStatus.CANCELLED)
                                orderToCancel = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Yes, Cancel")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderManagementCard(
    order: Order,
    items: List<com.example.data.model.OrderItem>,
    currency: String,
    onUpdateStatus: (OrderStatus) -> Unit,
    onAssignDelivery: () -> Unit,
    onCancelOrder: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.orderNumber}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Order #${order.orderNumber}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(formatDateTime(order.createdAt), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OrderStatusBadge(status = order.orderStatus)
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(8.dp))

            // Customer info & Phone
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(order.customerName, fontWeight = FontWeight.SemiBold)
                    Text(order.customerPhone, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (order.deliveryAddress.isNotBlank()) {
                        Text(order.deliveryAddress, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                if (order.customerPhone.isNotBlank()) {
                    IconButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.customerPhone}"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call", tint = PrimaryEmerald)
                    }
                }
            }

            // Delivery instructions if any
            if (order.deliveryInstructions.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Note: ${order.deliveryInstructions}",
                        fontSize = 11.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        modifier = Modifier.padding(6.dp)
                    )
                }
            }

            // Items List
            Spacer(modifier = Modifier.height(8.dp))
            items.forEach { item ->
                val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else "%.1f".format(item.quantity)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("${item.productName} ($qtyStr ${item.unit})", fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(formatCurrency(item.totalPrice, currency), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // Total & Payment info
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total: ${formatCurrency(order.totalAmount, currency)}", fontWeight = FontWeight.Bold, color = PrimaryEmerald, fontSize = 16.sp)
                    Text("${order.deliveryType.displayName} • ${order.paymentMethod.displayName} (${order.paymentStatus})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                if (order.assignedDeliveryStaffName.isNotBlank()) {
                    StatusBadge(
                        text = "Rider: ${order.assignedDeliveryStaffName}",
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            // Order Action Buttons according to current Status
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                when (order.orderStatus) {
                    OrderStatus.ORDER_RECEIVED -> {
                        Button(
                            onClick = { onUpdateStatus(OrderStatus.CONFIRMED) },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Confirm")
                        }
                        OutlinedButton(
                            onClick = onCancelOrder,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel")
                        }
                    }
                    OrderStatus.CONFIRMED -> {
                        Button(
                            onClick = { onUpdateStatus(OrderStatus.PREPARING) },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Start Preparing")
                        }
                    }
                    OrderStatus.PREPARING -> {
                        if (order.deliveryType == DeliveryType.HOME_DELIVERY) {
                            Button(
                                onClick = onAssignDelivery,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Assign Delivery Rider")
                            }
                        } else {
                            Button(
                                onClick = { onUpdateStatus(OrderStatus.READY_FOR_PICKUP) },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Ready for Pickup")
                            }
                        }
                    }
                    OrderStatus.OUT_FOR_DELIVERY, OrderStatus.READY_FOR_PICKUP -> {
                        Button(
                            onClick = { onUpdateStatus(if (order.deliveryType == DeliveryType.HOME_DELIVERY) OrderStatus.DELIVERED else OrderStatus.COMPLETED) },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (order.paymentStatus == PaymentStatus.PENDING) "Delivered & Collect Cash" else "Mark Delivered")
                        }
                    }
                    OrderStatus.DELIVERED, OrderStatus.COMPLETED -> {
                        Text("Order Completed Successfully", fontSize = 12.sp, color = StatusSuccess, fontWeight = FontWeight.SemiBold)
                    }
                    OrderStatus.CANCELLED, OrderStatus.REFUNDED -> {
                        Text("Order Cancelled (Stock Restored)", fontSize = 12.sp, color = StatusError)
                    }
                }
            }
        }
    }
}

@Composable
fun AssignDeliveryStaffDialog(
    order: Order,
    staffList: List<Employee>,
    onDismiss: () -> Unit,
    onAssign: (Long, String) -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Assign Delivery Agent", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("For Order #${order.orderNumber} (${order.customerName})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(14.dp))

                staffList.forEach { staff ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onAssign(staff.id, staff.name) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryEmerald)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(staff.name, fontWeight = FontWeight.Bold)
                                Text("${staff.role.displayName} • ${staff.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel")
                }
            }
        }
    }
}
