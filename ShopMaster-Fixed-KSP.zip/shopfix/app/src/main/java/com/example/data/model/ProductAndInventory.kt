package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val iconName: String = "store",
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

@Entity(
    tableName = "products",
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.SET_DEFAULT
        )
    ],
    indices = [Index(value = ["categoryId"]), Index(value = ["barcode"]), Index(value = ["sku"])]
)
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val categoryId: Long = 1,
    val description: String = "",
    val sellingPrice: Double,
    val costPrice: Double,
    val currentStock: Double,
    val minStockLevel: Double = 5.0,
    val unit: String = "pcs", // kg, g, l, ml, pack, pcs
    val sku: String = "",
    val barcode: String = "",
    val imageUrl: String = "",
    val isAvailable: Boolean = true,
    val allowBackorders: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "product_images",
    foreignKeys = [
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["productId"])]
)
data class ProductImage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val imageUrl: String,
    val isPrimary: Boolean = false
)

enum class MovementType(val displayName: String) {
    ONLINE_SALE("Online Sale"),
    OFFLINE_SALE("Offline Sale"),
    STOCK_RECEIVED("Stock Received"),
    DAMAGED("Damaged Stock"),
    LOST("Lost Stock"),
    RETURNED("Returned Stock"),
    MANUAL_ADJUSTMENT("Manual Adjustment")
}

@Entity(
    tableName = "inventory_movements",
    foreignKeys = [
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["productId"]), Index(value = ["timestamp"])]
)
data class InventoryMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val productName: String,
    val quantity: Double, // Positive for stock in / return, negative for sales / damage
    val movementType: MovementType,
    val previousStock: Double,
    val newStock: Double,
    val responsibleUser: String = "Staff",
    val reason: String = "",
    val referenceNumber: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
