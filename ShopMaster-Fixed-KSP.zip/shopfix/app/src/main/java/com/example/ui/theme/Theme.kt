package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = FreshGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = FreshGreenContainer,
    onPrimaryContainer = OnFreshGreenContainer,
    secondary = WarmSlateText,
    onSecondary = Color.White,
    secondaryContainer = WarmPeachContainer,
    onSecondaryContainer = WarmSlateDark,
    tertiary = GoldenAmber,
    onTertiary = Color.White,
    tertiaryContainer = GoldenAmberLight,
    onTertiaryContainer = GoldenAmberDark,
    background = WarmPeachBackground,
    onBackground = WarmSlateDark,
    surface = WarmPeachSurface,
    onSurface = WarmSlateDark,
    surfaceVariant = WarmPeachSurfaceVariant,
    onSurfaceVariant = WarmSlateMuted,
    outline = WarmPeachBorder,
    error = StatusError,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = FreshGreenPrimaryLight,
    onPrimary = Color.Black,
    primaryContainer = FreshGreenPrimaryDark,
    onPrimaryContainer = FreshGreenContainer,
    secondary = WarmSlateLight,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF2D3748),
    onSecondaryContainer = Color(0xFFF7FAFC),
    tertiary = GoldenAmber,
    onTertiary = Color.Black,
    tertiaryContainer = GoldenAmberDark,
    onTertiaryContainer = GoldenAmberLight,
    background = Color(0xFF181E24),
    onBackground = Color(0xFFF9FAFB),
    surface = Color(0xFF232A32),
    onSurface = Color(0xFFF9FAFB),
    surfaceVariant = Color(0xFF2E3842),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF3E4A56),
    error = StatusError,
    onError = Color.White
)

val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep consistent warm brand styling by default
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
