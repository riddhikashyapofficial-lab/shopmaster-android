package com.example.ui.analytics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.ui.AnalyticsTimeRange
import com.example.ui.ShopViewModel
import com.example.ui.components.SimpleBarChart
import com.example.ui.components.StatCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.components.formatDateOnly
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg

@Composable
fun AnalyticsAndReportsScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val analytics by viewModel.analyticsSummary.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val activeTimeRange by viewModel.analyticsTimeRange.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = PrimaryEmerald
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Sales & Profit P&L", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Expenses Log", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.MoneyOff, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Time Range Selector
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(AnalyticsTimeRange.values()) { r ->
                                FilterChip(
                                    selected = activeTimeRange == r,
                                    onClick = { viewModel.setAnalyticsTimeRange(r) },
                                    label = { Text(r.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PrimaryEmerald,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // Key Profit & Loss Cards
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard(
                                title = "Gross Revenue",
                                value = formatCurrency(analytics.totalRevenue, currency),
                                subtitle = "${analytics.totalTransactionsCount} orders & bills",
                                icon = Icons.Default.TrendingUp,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "Net Profit (After Exp)",
                                value = formatCurrency(analytics.netProfit, currency),
                                subtitle = "Gross profit - expenses",
                                icon = Icons.Default.AttachMoney,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Detailed P&L Breakdown Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Profit & Loss (P&L) Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(8.dp))

                                PlRow("Total Sales Revenue (Online + POS)", analytics.totalRevenue, isPositive = true, currency = currency)
                                PlRow("Cost of Goods Sold (COGS)", analytics.totalCostOfGoods, isPositive = false, currency = currency)
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                PlRow("Gross Profit", analytics.grossProfit, isPositive = true, isBold = true, currency = currency)
                                PlRow("Operating Expenses (Electricity, packaging, rent)", analytics.totalExpenses, isPositive = false, currency = currency)
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                                PlRow("NET SHOP PROFIT", analytics.netProfit, isPositive = analytics.netProfit >= 0, isBold = true, isHighlight = true, currency = currency)
                            }
                        }
                    }

                    // Sales by Channel
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Sales Channel Distribution", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Online Delivery & Pickup Orders:")
                                    Text("${analytics.onlineOrdersCount} orders", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("In-Store POS Counter Bills:")
                                    Text("${analytics.offlineSalesCount} bills", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Average Bill Value:")
                                    Text(formatCurrency(analytics.averageOrderValue, currency), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Payment Method Breakdown
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Revenue by Payment Method", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("💵 Cash (POS + COD):")
                                    Text(formatCurrency(analytics.cashSalesAmount, currency), fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("📱 Online UPI / QR:")
                                    Text(formatCurrency(analytics.upiSalesAmount, currency), fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("💳 Card Payments:")
                                    Text(formatCurrency(analytics.cardSalesAmount, currency), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Top Selling Items Leaderboard
                    if (analytics.bestSellingProducts.isNotEmpty()) {
                        item {
                            Text("🔥 Best Selling Products", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }

                        items(analytics.bestSellingProducts) { (prodName, totalSold) ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(prodName, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    StatusBadge(
                                        text = "${totalSold.toInt()} sold",
                                        containerColor = PrimaryEmerald.copy(alpha = 0.15f),
                                        contentColor = PrimaryEmerald
                                    )
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Expenses Log
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Store Expenses", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("Total Expenses: ${formatCurrency(expenses.sumOf { it.amount }, currency)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(
                                onClick = { showAddExpenseDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("add_expense_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Expense")
                            }
                        }
                    }

                    items(expenses) { exp ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(exp.category.displayName, fontWeight = FontWeight.Bold)
                                    Text(exp.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${formatDateOnly(exp.date)} • Paid via ${exp.paymentMethod.displayName} • By: ${exp.addedBy}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    text = "-${formatCurrency(exp.amount, currency)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = StatusError
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Expense Dialog
    if (showAddExpenseDialog) {
        AddExpenseDialog(
            currency = currency,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { cat, amt, desc, receipt ->
                viewModel.addExpense(cat, amt, PaymentMethod.CASH, desc, receipt)
                showAddExpenseDialog = false
            }
        )
    }
}

@Composable
fun PlRow(label: String, amount: Double, isPositive: Boolean, isBold: Boolean = false, isHighlight: Boolean = false, currency: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = if (isHighlight) 15.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isHighlight) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
        val prefix = if (isPositive) "+" else "-"
        Text(
            text = "$prefix${formatCurrency(amount, currency)}",
            fontSize = if (isHighlight) 16.sp else 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isHighlight) PrimaryEmerald else if (isPositive) StatusSuccess else StatusError
        )
    }
}

@Composable
fun AddExpenseDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (ExpenseCategory, Double, String, String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.RENT) }
    var amountInput by remember { mutableStateOf("1000") }
    var description by remember { mutableStateOf("") }
    var receiptNote by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Add Shop Operating Expense", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ExpenseCategory.values()) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.displayName) }
                        )
                    }
                }

                OutlinedTextField(value = amountInput, onValueChange = { amountInput = it }, label = { Text("Expense Amount ($currency) *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description / Purpose *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = receiptNote, onValueChange = { receiptNote = it }, label = { Text("Invoice / Receipt # (Optional)") }, modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && description.isNotBlank()) {
                                onSave(selectedCategory, amt, description, receiptNote)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Expense")
                    }
                }
            }
        }
    }
}
