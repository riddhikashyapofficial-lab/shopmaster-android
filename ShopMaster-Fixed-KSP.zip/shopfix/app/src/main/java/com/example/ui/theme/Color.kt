package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Peach & Soft Golden Palette - Inspired by Modern Mobile App Shopping Experience
val WarmPeachBackground = Color(0xFFFFF8F1)      // Main warm canvas
val WarmPeachSurface = Color(0xFFFFFFFF)         // Clean crisp white cards
val WarmPeachSurfaceVariant = Color(0xFFFBF1E6)  // Soft warm card variant
val WarmPeachBorder = Color(0xFFF3E5D4)          // Soft warm border
val WarmPeachContainer = Color(0xFFFEEDD8)       // Highlighted container

// Fresh Vibrant Green Primary Action Colour
val FreshGreenPrimary = Color(0xFF059669)        // Fresh Green (actions, active pills)
val FreshGreenPrimaryLight = Color(0xFF10B981)   // Vibrant emerald light
val FreshGreenPrimaryDark = Color(0xFF047857)    // Dark emerald
val FreshGreenContainer = Color(0xFFDCFCE7)      // Light green pill container
val OnFreshGreenContainer = Color(0xFF065F46)    // Dark green text on container

// Secondary Warm Neutral & Slate
val WarmSlateDark = Color(0xFF1F2937)            // Dark charcoal text
val WarmSlateText = Color(0xFF374151)            // Body text
val WarmSlateMuted = Color(0xFF6B7280)           // Secondary / muted text
val WarmSlateLight = Color(0xFF9CA3AF)           // Subdued helper text

// Accent Golden / Amber
val GoldenAmber = Color(0xFFF59E0B)
val GoldenAmberLight = Color(0xFFFEF3C7)
val GoldenAmberDark = Color(0xFFB45309)

// Semantic Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessBg = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusError = Color(0xFFEF4444)
val StatusErrorBg = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF3B82F6)
val StatusInfoBg = Color(0xFFDBEAFE)

// Backwards compatibility aliases
val PrimaryEmerald = FreshGreenPrimary
val PrimaryEmeraldLight = FreshGreenPrimaryLight
val PrimaryEmeraldDark = FreshGreenPrimaryDark
val PrimaryContainer = FreshGreenContainer
val OnPrimaryContainer = OnFreshGreenContainer
val NeutralBackground = WarmPeachBackground
val NeutralSurface = WarmPeachSurface
val NeutralSurfaceVariant = WarmPeachSurfaceVariant
val NeutralBorder = WarmPeachBorder
val TextPrimary = WarmSlateDark
val TextSecondary = WarmSlateText
val TextMuted = WarmSlateMuted
